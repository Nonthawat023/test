﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SF80_Dashboard_2.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace SF80_Dashboard_2.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly QueryController _qr;
        private dynamic click;

        //Dependency Injection (DI)
        public HomeController(ILogger<HomeController> logger,QueryController _qr)
        {
            _logger = logger;
            this._qr = _qr;
        }

        public IActionResult Index()
        {
            
            return View();
        }

        public IActionResult Page1(int NumA ,int NumB)
        {
            ViewBag.value = NumA * NumB;
            return View();
        }
        public IActionResult Page2()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Page3()
        {
          
            return View();
        }

        public IActionResult Page4()
        {

            return View();
        }

        public IActionResult Page5()
        {

            return View();
        }

        public IActionResult Page6()
        {

            return View();
        }

        public IActionResult Page7()
        {

            return View();
        }

        public IActionResult Page8()
        {

            return View();
        }

        public IActionResult Page9()
        {

            return View();
        }

        public IActionResult Chart()
        {

            return View();
        }

        public IActionResult PageChart()
        {

            return View();
        }

        public IActionResult Page10()
        {

            return View();
        }
        [HttpPost]
        public string TestParameter([FromBody] Params param)
        {
            string TestVal = param.param1.ToString();
            return TestVal;
        }

        public JsonResult GetDB()
        {
            var data = _qr._query("SELECT * FROM tbName_Patchara");
            return data;
        }
        public JsonResult GetDB1()
        {
            var data = _qr._query("SELECT TOP 5 * FROM tbDash_T4_SumPlan");
            return data;
        }
        public JsonResult GetDB5()
        {
            var data = _qr._query("SELECT TOP 5 * FROM TBL_FacilityReport_Conf");
            return data;
        }
        public JsonResult GetDB2()
        {
            var data = _qr._query(@"Exec sp_Training_BarChart");
            return data;
        }
        public JsonResult GetDataBarChart()
        {
            var data = _qr._query(@"Exec sp_Training_BarChart");
            return data;
        }
        public JsonResult GetDataBarChart2()
        {
            var data = _qr._query(@"Exec sp_Training_BarChart2");
            return data;
        }
        public JsonResult GetInputProgress()
        {
            var data = _qr._query(@"Exec sp_DProduct_Progress 'Input','IS' ");
            return data;
        }
        public JsonResult GetMCTotalStatus()
        {
            var data = _qr._query(@"Exec sp_DMachine_TotalStatus 'Input','IS' ");
            return data;
        }
        public JsonResult GetCustomerZone()
        {
            var data = _qr._query(@"Exec sp_DCustmr_CustomerZone");
            return data;
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
