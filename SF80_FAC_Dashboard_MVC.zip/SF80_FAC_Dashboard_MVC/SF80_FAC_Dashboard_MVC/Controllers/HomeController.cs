﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SF80_FAC_Dashboard_MVC.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;


namespace SF80_FAC_Dashboard_MVC.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly QueryController _qr;
        private readonly IConfiguration config;

        public HomeController(ILogger<HomeController> logger, QueryController _qr, IConfiguration config)
        {
            _logger = logger;
            this._qr = _qr;
            this.config = config;
        }
        public IActionResult Test()
        {
            var valuesGaugeA1_1 = GetUtilityA1_1Decimal();
            var valuesGaugeA1_2 = GetUtilityA1_2Decimal();
            var valuesGaugeA1_3 = GetUtilityA1_3Decimal();
            var valuesGaugeA1_4 = GetUtilityA1_4Decimal();
            var valuesGaugeA1_5 = GetUtilityA1_5Decimal();
            var valuesGaugeA1_6 = GetUtilityA1_6Decimal();
            var valuesGaugeA1_7 = GetUtilityA1_7Decimal();
            var valuesGaugeA1_8 = GetUtilityA1_8Decimal();


            ViewData["valuesGaugeA1_1"] = JsonConvert.SerializeObject(valuesGaugeA1_1);
            ViewData["valuesGaugeA1_2"] = JsonConvert.SerializeObject(valuesGaugeA1_2);
            ViewData["valuesGaugeA1_3"] = JsonConvert.SerializeObject(valuesGaugeA1_3);
            ViewData["valuesGaugeA1_4"] = JsonConvert.SerializeObject(valuesGaugeA1_4);
            ViewData["valuesGaugeA1_5"] = JsonConvert.SerializeObject(valuesGaugeA1_5);
            ViewData["valuesGaugeA1_6"] = JsonConvert.SerializeObject(valuesGaugeA1_6);
            ViewData["valuesGaugeA1_7"] = JsonConvert.SerializeObject(valuesGaugeA1_7);
            ViewData["valuesGaugeA1_8"] = JsonConvert.SerializeObject(valuesGaugeA1_8);
            return View();
        }
        public IActionResult Index()
        {
            var valuesGaugeA1_1 = GetUtilityA1_1Decimal();
            var valuesGaugeA1_2 = GetUtilityA1_2Decimal();
            var valuesGaugeA1_3 = GetUtilityA1_3Decimal();
            var valuesGaugeA1_4 = GetUtilityA1_4Decimal();
            var valuesGaugeA1_5 = GetUtilityA1_5Decimal();
            var valuesGaugeA1_6 = GetUtilityA1_6Decimal();
            var valuesGaugeA1_7 = GetUtilityA1_7Decimal();
            var valuesGaugeA1_8 = GetUtilityA1_8Decimal();

            var valuesGaugeA2_1 = GetUtilityA2_1Decimal();
            var valuesGaugeA2_2 = GetUtilityA2_2Decimal();
            var valuesGaugeA2_3 = GetUtilityA2_3Decimal();
            var valuesGaugeA2_4 = GetUtilityA2_4Decimal();
            var valuesGaugeA2_5 = GetUtilityA2_5Decimal();
            var valuesGaugeA2_6 = GetUtilityA2_6Decimal();

            var valuesGaugeDIW1_1 = GetUtilityDIW1_1Decimal();
            var valuesGaugeDIW1_2 = GetUtilityDIW1_2Decimal();
            var valuesGaugeDIW2_1 = GetUtilityDIW2_1Decimal();
            var valuesGaugeDIW2_2 = GetUtilityDIW2_2Decimal();
            var valuesGaugeDIW3_1 = GetUtilityDIW3_1Decimal();
            var valuesGaugeDIW3_2 = GetUtilityDIW3_2Decimal();
            var valuesGaugeDIW4_1 = GetUtilityDIW4_1Decimal();
            var valuesGaugeDIW4_2 = GetUtilityDIW4_2Decimal();
            var valuesGaugeDIW5_1 = GetUtilityDIW5_1Decimal();
            var valuesGaugeDIW5_2 = GetUtilityDIW5_2Decimal();
            var valuesGaugeDIW6_1 = GetUtilityDIW6_1Decimal();
            var valuesGaugeDIW6_2 = GetUtilityDIW6_2Decimal();


            ViewData["valuesGaugeA1_1"] = JsonConvert.SerializeObject(valuesGaugeA1_1);
            ViewData["valuesGaugeA1_2"] = JsonConvert.SerializeObject(valuesGaugeA1_2);
            ViewData["valuesGaugeA1_3"] = JsonConvert.SerializeObject(valuesGaugeA1_3);
            ViewData["valuesGaugeA1_4"] = JsonConvert.SerializeObject(valuesGaugeA1_4);
            ViewData["valuesGaugeA1_5"] = JsonConvert.SerializeObject(valuesGaugeA1_5);
            ViewData["valuesGaugeA1_6"] = JsonConvert.SerializeObject(valuesGaugeA1_6);
            ViewData["valuesGaugeA1_7"] = JsonConvert.SerializeObject(valuesGaugeA1_7);
            ViewData["valuesGaugeA1_8"] = JsonConvert.SerializeObject(valuesGaugeA1_8);

            ViewData["valuesGaugeA2_1"] = JsonConvert.SerializeObject(valuesGaugeA2_1);
            ViewData["valuesGaugeA2_2"] = JsonConvert.SerializeObject(valuesGaugeA2_2);
            ViewData["valuesGaugeA2_3"] = JsonConvert.SerializeObject(valuesGaugeA2_3);
            ViewData["valuesGaugeA2_4"] = JsonConvert.SerializeObject(valuesGaugeA2_4);
            ViewData["valuesGaugeA2_5"] = JsonConvert.SerializeObject(valuesGaugeA2_5);
            ViewData["valuesGaugeA2_6"] = JsonConvert.SerializeObject(valuesGaugeA2_6);

            ViewData["valuesGaugeDIW1_1"] = JsonConvert.SerializeObject(valuesGaugeDIW1_1);
            ViewData["valuesGaugeDIW1_2"] = JsonConvert.SerializeObject(valuesGaugeDIW1_2);
            ViewData["valuesGaugeDIW2_1"] = JsonConvert.SerializeObject(valuesGaugeDIW2_1);
            ViewData["valuesGaugeDIW2_2"] = JsonConvert.SerializeObject(valuesGaugeDIW2_2);
            ViewData["valuesGaugeDIW3_1"] = JsonConvert.SerializeObject(valuesGaugeDIW3_1);
            ViewData["valuesGaugeDIW3_2"] = JsonConvert.SerializeObject(valuesGaugeDIW3_2);
            ViewData["valuesGaugeDIW4_1"] = JsonConvert.SerializeObject(valuesGaugeDIW4_1);
            ViewData["valuesGaugeDIW4_2"] = JsonConvert.SerializeObject(valuesGaugeDIW4_2);
            ViewData["valuesGaugeDIW5_1"] = JsonConvert.SerializeObject(valuesGaugeDIW5_1);
            ViewData["valuesGaugeDIW5_2"] = JsonConvert.SerializeObject(valuesGaugeDIW5_2);
            ViewData["valuesGaugeDIW6_1"] = JsonConvert.SerializeObject(valuesGaugeDIW6_1);
            ViewData["valuesGaugeDIW6_2"] = JsonConvert.SerializeObject(valuesGaugeDIW6_2);

            return View();
        }
        #region All Gauge
        public decimal GetUtilityA1_1Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F8, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        public decimal GetUtilityA1_2Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F11, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        public decimal GetUtilityA1_3Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F21, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        public decimal GetUtilityA1_4Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F22, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        public decimal GetUtilityA1_5Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F10, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        public decimal GetUtilityA1_6Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F12, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        public decimal GetUtilityA1_7Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F13, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        public decimal GetUtilityA1_8Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F14, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        #endregion

        #region All Gauge B#2
        public decimal GetUtilityA2_1Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F2, TBL_FacilityReport_Utility_Supply_B2");
            return data;
        }
        public decimal GetUtilityA2_2Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F6, TBL_FacilityReport_Utility_Supply_B2");
            return data;
        }
        public decimal GetUtilityA2_3Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F4, TBL_FacilityReport_Utility_Supply_B2");
            return data;
        }
        public decimal GetUtilityA2_4Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F5, TBL_FacilityReport_Utility_Supply_B2");
            return data;
        }
        public decimal GetUtilityA2_5Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F3, TBL_FacilityReport_Utility_Supply_B2");
            return data;
        }
        public decimal GetUtilityA2_6Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F7, TBL_FacilityReport_Utility_Supply_B2");
            return data;
        }
        #endregion

        #region All Gauge DIW
        public decimal GetUtilityDIW1_1Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F3, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public decimal GetUtilityDIW1_2Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F9, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public decimal GetUtilityDIW2_1Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F7, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public decimal GetUtilityDIW2_2Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F13, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public decimal GetUtilityDIW3_1Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F5, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public decimal GetUtilityDIW3_2Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F11, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public decimal GetUtilityDIW4_1Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F6, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public decimal GetUtilityDIW4_2Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F12, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public decimal GetUtilityDIW5_1Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F4, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public decimal GetUtilityDIW5_2Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F10, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public decimal GetUtilityDIW6_1Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F2, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public decimal GetUtilityDIW6_2Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F8, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        #endregion


        public JsonResult GetRealtimeTemp([FromBody] AreaModel area)
        {

            var data = _qr._query(@"Exec SP_Get_Realtime_Temp " + area.Temp + ", " + area.RH + ", " + area.area);
            return data;
        }
        public JsonResult GetRealtimeTempB1()
        {

            var data = _qr._query(@"Exec SP_Get_Realtime_Temp TBL_FacilityReport_ENVIRMENT");
            return data;
        }
        public JsonResult GetRealtimeTempB2()
        {

            var data = _qr._query(@"Exec SP_Get_Realtime_Temp TBL_FacilityReport_B2_ENVIRONMENT");
            return data;
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
