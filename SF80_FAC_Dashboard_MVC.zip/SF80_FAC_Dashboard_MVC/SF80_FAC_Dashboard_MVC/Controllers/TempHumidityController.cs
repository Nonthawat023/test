﻿using Microsoft.AspNetCore.Mvc;
using SF80_FAC_Dashboard_MVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SF80_FAC_Dashboard_MVC.Controllers
{
    public class TempHumidityController : Controller
    {
        private readonly QueryController _qr;
        public TempHumidityController(QueryController _qr)
        {
            this._qr = _qr;
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult BuildingOne()
        {
            return View();
        }
        public IActionResult BuildingTwo()
        {
            return View();
        }
        public IActionResult B1_1K()
        {
          
            return View("Building1/B1_1K");
        }
        public IActionResult B1B1_10K()
        {
            return View("Building1/B1B1_10K");
        }
        public IActionResult B1B2()
        {
            return View("Building1/B1B2");
        }
        public IActionResult B1B3()
        {
            return View("Building1/B1B3");
        }
        public IActionResult B1B4()
        {
            return View("Building1/B1B4");
        }
        public IActionResult B1B4_1()
        {
            return View("Building1/B1B4_1");
        }
        public IActionResult B1W_H()
        {
            return View("Building1/B1W_H");
        }
        public IActionResult B1FG_B1()
        {
            return View("Building1/B1FG_B1");
        }
        public IActionResult B2QAT()
        {
            return View("Building2/B2QAT");
        }
        public IActionResult B2SPECIFIC()
        {
            return View("Building2/B2SPECIFIC");
        }
        public IActionResult B2ABC_WH()
        {
            return View("Building2/B2ABC_WH");
        }
        public IActionResult B2REALIBILITY()
        {
            return View("Building2/B2REALIBILITY");
        }
        public IActionResult B2FG_B2()
        {
            return View("Building2/B2FG_B2");
        }

        public JsonResult GetTempTable()
        {

            var data = _qr._query(@"Exec SP_GetTable_Temp_and_Humidity 'TBL_FacilityReport_ENVIRMENT'");
            return data;
        }
        public JsonResult PostTempData([FromBody] AreaModel temp)
        {
            var data = _qr._query(@"Exec SP_Get_Temp_and_Humidity " + temp.Temp + ", '" + temp.StartDate + "', '" + temp.EndDate + "', 'TBL_FacilityReport_ENVIRMENT'");
            return data;
        }
        public JsonResult PostPressureData([FromBody] AreaModel Pressure)
        {
            var data = _qr._query(@"Exec SP_Get_Temp_and_Humidity " + Pressure.Pressure + ", TBL_FacilityReport_ENVIRMENT");
            return data;
        }
        public JsonResult PostRHData([FromBody] AreaModel RH)
        {
            var data = _qr._query(@"Exec SP_Get_Temp_and_Humidity " + RH.RH + ", '" + RH.StartDate + "', '" + RH.EndDate + "', 'TBL_FacilityReport_ENVIRMENT'");
            return data;
        }

        //Building 2
        public JsonResult PostTempDataB2([FromBody] AreaModel temp)
        {
            //var data = _qr._query(@"Exec SP_Get_Temp_and_Humidity " + "'" + temp.Temp + "','TBL_FacilityReport_B2_ENVIRONMENT'");
            var data = _qr._query(@"Exec SP_Get_Temp_and_Humidity " + temp.Temp + ", '" + temp.StartDate + "', '" + temp.EndDate + "', 'TBL_FacilityReport_B2_ENVIRONMENT'");

            return data;
        }
        public JsonResult PostPressureDataB2([FromBody] AreaModel Pressure)
        {
            var data = _qr._query(@"Exec SP_Get_Temp_and_Humidity " + "'" + Pressure.Pressure + "','TBL_FacilityReport_B2_ENVIRONMENT'");
            return data;
        }
        public JsonResult PostRHDataB2([FromBody] AreaModel RH)
        {
            //var data = _qr._query(@"Exec SP_Get_Temp_and_Humidity " + "'" + RH.RH + "','TBL_FacilityReport_B2_ENVIRONMENT'");
            var data = _qr._query(@"Exec SP_Get_Temp_and_Humidity " + RH.RH + ", '" + RH.StartDate + "', '" + RH.EndDate + "', 'TBL_FacilityReport_B2_ENVIRONMENT'");

            return data;
        }
        

    }
}
