﻿using Microsoft.AspNetCore.Mvc;
using SF80_FAC_Dashboard_MVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SF80_FAC_Dashboard_MVC.Controllers
{
    public class EnergyController : Controller
    {
        private readonly QueryController _qr;
        public EnergyController(QueryController _qr)
        {
            this._qr = _qr;
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult EnergyMFG()
        {
            return View();
        }
        public IActionResult UtilitySupply()
        {
            return View();
        }
        public IActionResult Office()
        {
            return View();
        }
        public IActionResult Lighting()
        {
            return View();
        }
        public JsonResult PostTempData([FromBody] AreaModel test)
        {
            //string user = HttpContext.Session.GetString(userId);
            //string test = user;
            //var test = ViewData["Message"];
            if (string.IsNullOrEmpty(test.areaselect))
            {
                test.areaselect = "F32";
            }

            var data = _qr._query(@"Exec SP_ShowEnergy_TEST " + "'" + test.areaselect + "'");
            return data;
        }

    }
}
