﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SF80_FAC_Dashboard_MVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SF80_FAC_Dashboard_MVC.Controllers
{
    public class UtilityController : Controller
    {
        private readonly QueryController _qr;
        public UtilityController(QueryController _qr)
        {
            this._qr = _qr;
        }

        public IActionResult Index()
        {
            var valuesGaugeA1_1 = GetUtilityA1_1Decimal();
            var valuesGaugeA1_2 = GetUtilityA1_2Decimal();
            var valuesGaugeA1_3 = GetUtilityA1_3Decimal();
            var valuesGaugeA1_4 = GetUtilityA1_4Decimal();
            var valuesGaugeA1_5 = GetUtilityA1_5Decimal();
            var valuesGaugeA1_6 = GetUtilityA1_6Decimal();
            var valuesGaugeA1_7 = GetUtilityA1_7Decimal();
            var valuesGaugeA1_8 = GetUtilityA1_8Decimal();

            ViewData["valuesGaugeA1_1"] = JsonConvert.SerializeObject(valuesGaugeA1_1);
            ViewData["valuesGaugeA1_2"] = JsonConvert.SerializeObject(valuesGaugeA1_2);
            ViewData["valuesGaugeA1_3"] = JsonConvert.SerializeObject(valuesGaugeA1_3);
            ViewData["valuesGaugeA1_4"] = JsonConvert.SerializeObject(valuesGaugeA1_4);
            ViewData["valuesGaugeA1_5"] = JsonConvert.SerializeObject(valuesGaugeA1_5);
            ViewData["valuesGaugeA1_6"] = JsonConvert.SerializeObject(valuesGaugeA1_6);
            ViewData["valuesGaugeA1_7"] = JsonConvert.SerializeObject(valuesGaugeA1_7);
            ViewData["valuesGaugeA1_8"] = JsonConvert.SerializeObject(valuesGaugeA1_8);


            return View();
        }
        public IActionResult B1_CDA()
        {
            return View("B1/CDA");
        }
        public IActionResult B1_PDV()
        {
            return View("B1/PDV");
        }
        public IActionResult B1_PCW()
        {
            return View("B1/PCW");
        }
        public IActionResult B1_VP()
        {
            return View("B1/VP");
        }

        public IActionResult UtilityB2()
        {
            var valuesGaugeA2_1 = GetUtilityA2_1Decimal();
            var valuesGaugeA2_2 = GetUtilityA2_2Decimal();
            var valuesGaugeA2_3 = GetUtilityA2_3Decimal();
            var valuesGaugeA2_4 = GetUtilityA2_4Decimal();
            var valuesGaugeA2_5 = GetUtilityA2_5Decimal();
            var valuesGaugeA2_6 = GetUtilityA2_6Decimal();

            ViewData["valuesGaugeA2_1"] = JsonConvert.SerializeObject(valuesGaugeA2_1);
            ViewData["valuesGaugeA2_2"] = JsonConvert.SerializeObject(valuesGaugeA2_2);
            ViewData["valuesGaugeA2_3"] = JsonConvert.SerializeObject(valuesGaugeA2_3);
            ViewData["valuesGaugeA2_4"] = JsonConvert.SerializeObject(valuesGaugeA2_4);
            ViewData["valuesGaugeA2_5"] = JsonConvert.SerializeObject(valuesGaugeA2_5);
            ViewData["valuesGaugeA2_6"] = JsonConvert.SerializeObject(valuesGaugeA2_6);
            return View();
        }
        public IActionResult B2_CDA()
        {
            return View("B2/CDA");
        }
        public IActionResult B2_PDV()
        {
            return View("B2/PDV");
        }
        public IActionResult B2_PCW()
        {
            return View("B2/PCW");
        }
        public IActionResult B2_VP()
        {
            return View("B2/VP");
        }
        public IActionResult UtilityDIW()
        {
            var valuesGaugeDIW1_1 = GetUtilityDIW1_1Decimal();
            var valuesGaugeDIW1_2 = GetUtilityDIW1_2Decimal();
            var valuesGaugeDIW2_1 = GetUtilityDIW2_1Decimal();
            var valuesGaugeDIW2_2 = GetUtilityDIW2_2Decimal();
            var valuesGaugeDIW3_1 = GetUtilityDIW3_1Decimal();
            var valuesGaugeDIW3_2 = GetUtilityDIW3_2Decimal();
            var valuesGaugeDIW4_1 = GetUtilityDIW4_1Decimal();
            var valuesGaugeDIW4_2 = GetUtilityDIW4_2Decimal();
            var valuesGaugeDIW5_1 = GetUtilityDIW5_1Decimal();
            var valuesGaugeDIW5_2 = GetUtilityDIW5_2Decimal();
            var valuesGaugeDIW6_1 = GetUtilityDIW6_1Decimal();
            var valuesGaugeDIW6_2 = GetUtilityDIW6_2Decimal();

            ViewData["valuesGaugeDIW1_1"] = JsonConvert.SerializeObject(valuesGaugeDIW1_1);
            ViewData["valuesGaugeDIW1_2"] = JsonConvert.SerializeObject(valuesGaugeDIW1_2);
            ViewData["valuesGaugeDIW2_1"] = JsonConvert.SerializeObject(valuesGaugeDIW2_1);
            ViewData["valuesGaugeDIW2_2"] = JsonConvert.SerializeObject(valuesGaugeDIW2_2);
            ViewData["valuesGaugeDIW3_1"] = JsonConvert.SerializeObject(valuesGaugeDIW3_1);
            ViewData["valuesGaugeDIW3_2"] = JsonConvert.SerializeObject(valuesGaugeDIW3_2);
            ViewData["valuesGaugeDIW4_1"] = JsonConvert.SerializeObject(valuesGaugeDIW4_1);
            ViewData["valuesGaugeDIW4_2"] = JsonConvert.SerializeObject(valuesGaugeDIW4_2);
            ViewData["valuesGaugeDIW5_1"] = JsonConvert.SerializeObject(valuesGaugeDIW5_1);
            ViewData["valuesGaugeDIW5_2"] = JsonConvert.SerializeObject(valuesGaugeDIW5_2);
            ViewData["valuesGaugeDIW6_1"] = JsonConvert.SerializeObject(valuesGaugeDIW6_1);
            ViewData["valuesGaugeDIW6_2"] = JsonConvert.SerializeObject(valuesGaugeDIW6_2);
            return View();
        }
        public IActionResult DIW_Resistivity()
        {
            return View("DIW/Resistivity");
        }
        public IActionResult DIW_pH()
        {
            return View("DIW/pH");
        }
        public IActionResult DIW_Particle()
        {
            return View("DIW/Particle");
        }
        public IActionResult DIW_Temperature()
        {
            return View("DIW/Temperature");
        }
        public IActionResult DIW_Pressure()
        {
            return View("DIW/Pressure");
        }
        public IActionResult DIW_TOC()
        {
            return View("DIW/TOC");
        }

        public IActionResult UtilityElectric()
        {
            return View();
        }

        #region All Gauge Building#1
        public JsonResult GetUtilityA1_1()
        {

            var data = _qr._query(@"Exec SP_Get_Utility F8, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        public JsonResult GetUtilityA1_2()
        {
            var data = _qr._query(@"Exec SP_Get_Utility F11, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        public JsonResult GetUtilityA1_3()
        {
            var data = _qr._query(@"Exec SP_Get_Utility F21, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        public JsonResult GetUtilityA1_4()
        {
            var data = _qr._query(@"Exec SP_Get_Utility F22, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        public JsonResult GetUtilityA1_5()
        {

            var data = _qr._query(@"Exec SP_Get_Utility F10, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        public JsonResult GetUtilityA1_6()
        {

            var data = _qr._query(@"Exec SP_Get_Utility F12, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        public JsonResult GetUtilityA1_7()
        {

            var data = _qr._query(@"Exec SP_Get_Utility F13, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        public JsonResult GetUtilityA1_8()
        {

            var data = _qr._query(@"Exec SP_Get_Utility F14, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        #region All Gauge
        public decimal GetUtilityA1_1Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F8, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        public decimal GetUtilityA1_2Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F11, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        public decimal GetUtilityA1_3Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F21, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        public decimal GetUtilityA1_4Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F22, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        public decimal GetUtilityA1_5Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F10, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        public decimal GetUtilityA1_6Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F12, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        public decimal GetUtilityA1_7Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F13, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        public decimal GetUtilityA1_8Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F14, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        #endregion

        #endregion

        #region All Gauge Building#2
        public JsonResult GetUtilityA2_1()
        {

            var data = _qr._query(@"Exec SP_Get_Utility F2, TBL_FacilityReport_Utility_Supply_B2");
            return data;
        }
        public JsonResult GetUtilityA2_2()
        {
            var data = _qr._query(@"Exec SP_Get_Utility F6, TBL_FacilityReport_Utility_Supply_B2");
            return data;
        }
        public JsonResult GetUtilityA2_3()
        {
            var data = _qr._query(@"Exec SP_Get_Utility F4, TBL_FacilityReport_Utility_Supply_B2");
            return data;
        }
        public JsonResult GetUtilityA2_4()
        {
            var data = _qr._query(@"Exec SP_Get_Utility F5, TBL_FacilityReport_Utility_Supply_B2");
            return data;
        }
        public JsonResult GetUtilityA2_5()
        {
            
            var data = _qr._query(@"Exec SP_Get_Utility F3, TBL_FacilityReport_Utility_Supply_B2");
            return data;
        }
        public JsonResult GetUtilityA2_6()
        {
            //ยังไม่มีข้อมูล ยะงใช้ข้อมูลแทนเพื่อการจำลอง
            var data = _qr._query(@"Exec SP_Get_Utility F7, TBL_FacilityReport_Utility_Supply_B2");
            return data;
        }
        #region All Gauge
        public decimal GetUtilityA2_1Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F2, TBL_FacilityReport_Utility_Supply_B2");
            return data;
        }
        public decimal GetUtilityA2_2Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F6, TBL_FacilityReport_Utility_Supply_B2");
            return data;
        }
        public decimal GetUtilityA2_3Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F4, TBL_FacilityReport_Utility_Supply_B2");
            return data;
        }
        public decimal GetUtilityA2_4Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F5, TBL_FacilityReport_Utility_Supply_B2");
            return data;
        }
        public decimal GetUtilityA2_5Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F3, TBL_FacilityReport_Utility_Supply_B2");
            return data;
        }
        public decimal GetUtilityA2_6Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F7, TBL_FacilityReport_Utility_Supply_B2");
            return data;
        }
        #endregion

        #endregion

        #region All Gauge DIW
        public JsonResult GetUtilityDIW1_1()
        {

            var data = _qr._query(@"Exec SP_Get_Utility F3, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public JsonResult GetUtilityDIW1_2()
        {
            var data = _qr._query(@"Exec SP_Get_Utility F9, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public JsonResult GetUtilityDIW2_1()
        {
            var data = _qr._query(@"Exec SP_Get_Utility F7, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public JsonResult GetUtilityDIW2_2()
        {
            var data = _qr._query(@"Exec SP_Get_Utility F13, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public JsonResult GetUtilityDIW3_1()
        {

            var data = _qr._query(@"Exec SP_Get_Utility F5, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public JsonResult GetUtilityDIW3_2()
        {

            var data = _qr._query(@"Exec SP_Get_Utility F11, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public JsonResult GetUtilityDIW4_1()
        {

            var data = _qr._query(@"Exec SP_Get_Utility F6, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public JsonResult GetUtilityDIW4_2()
        {
            var data = _qr._query(@"Exec SP_Get_Utility F12, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public JsonResult GetUtilityDIW5_1()
        {
            var data = _qr._query(@"Exec SP_Get_Utility F4, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public JsonResult GetUtilityDIW5_2()
        {
            var data = _qr._query(@"Exec SP_Get_Utility F10, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public JsonResult GetUtilityDIW6_1()
        {

            var data = _qr._query(@"Exec SP_Get_Utility F2, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public JsonResult GetUtilityDIW6_2()
        {

            var data = _qr._query(@"Exec SP_Get_Utility F8, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        #region All Gauge
        public decimal GetUtilityDIW1_1Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F3, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public decimal GetUtilityDIW1_2Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F9, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public decimal GetUtilityDIW2_1Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F7, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public decimal GetUtilityDIW2_2Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F13, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public decimal GetUtilityDIW3_1Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F5, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public decimal GetUtilityDIW3_2Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F11, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public decimal GetUtilityDIW4_1Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F6, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public decimal GetUtilityDIW4_2Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F12, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public decimal GetUtilityDIW5_1Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F4, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public decimal GetUtilityDIW5_2Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F10, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public decimal GetUtilityDIW6_1Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F2, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        public decimal GetUtilityDIW6_2Decimal()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F8, TBL_FacilityReport_Utility_Supply_DIW");
            return data;
        }
        #endregion

        #endregion
        public JsonResult PostChart_Utility([FromBody] UtilityModel model)
        {
            var data = _qr._query(@"Exec SP_Get_Chart_Utility " + model.area + ", '" + model.Table + "', '" + model.StartDate + "', '" + model.EndDate + "'");
            return data;
        }

        //public JsonResult PostChart_Utility2([FromBody] UtilityModel loop)
        //{
        //    var data = _qr._query(@"Exec SP_Get_Chart_Utility " + loop.area + ", '" + loop.Table + "', '" + loop.StartDate + "', '" + loop.EndDate + "'");
        //}

        //[HttpPost]
        //public JsonResult PostUtility([FromBody] EnergyModel gauge)
        //{
        //    var data = _qr._query(@"Exec SP_Get_Utility " + "'" + gauge.gaugeArea + "','TBL_FacilityReport_Utility_Supply'");
        //    return data;
        //}

    }
}
