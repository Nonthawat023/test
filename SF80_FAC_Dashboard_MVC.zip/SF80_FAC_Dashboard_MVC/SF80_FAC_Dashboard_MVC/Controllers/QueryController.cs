﻿using ClosedXML.Excel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Threading.Tasks;

namespace SF80_FAC_Dashboard_MVC.Controllers
{
    public class QueryController : Controller
    {
        private readonly IConfiguration config; // conection DB
        //common
        public QueryController(IConfiguration config)
        {
            this.config = config;
        }
        public JsonResult ConvertJson(DataTable dt)
        {
            //Convert Dataset to Json
            List<Dictionary<string, object>> _json = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.ColumnName, dr[col].ToString());
                }
                _json.Add(row);
            }
            return Json(_json);
        }
        
        //*** Get: Query ปกติ ***//
        public JsonResult _query(string query)
        {
            DataTable dt = new DataTable();
            string dbcon = config.GetConnectionString("Constr");
            using (SqlConnection cnn = new SqlConnection(dbcon))
            {
                cnn.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter(query, cnn);
                sqlDa.Fill(dt);
                cnn.Close();
            }
            var _json = ConvertJson(dt);
            return _json;
        }

        //public JsonResult _queryFAC(string queryFAC)
        //{
        //    DataTable dt = new DataTable();
        //    string dbcon = config.GetConnectionString("ConstrFAC");
        //    using (SqlConnection cnn = new SqlConnection(dbcon))
        //    {
        //        cnn.Open();
        //        SqlDataAdapter sqlDa = new SqlDataAdapter(queryFAC, cnn);
        //        sqlDa.Fill(dt);
        //        cnn.Close();
        //    }
        //    var _json = ConvertJson(dt);
        //    return _json;
        //}
        public int _query_row_count(string query)
        {
            DataTable dt = new DataTable();
            string dbcon = config.GetConnectionString("Constr");
            using (SqlConnection cnn = new SqlConnection(dbcon))
            {
                cnn.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter(query, cnn);
                sqlDa.Fill(dt);
                cnn.Close();
            }
            int _data = dt.Rows.Count;
            return _data;
        }

        //** Get:Query Scarlar Int **//
        public int _query_scalar(string query)
        {
            string dbcon = config.GetConnectionString("Constr");
            SqlConnection cnn = new SqlConnection(dbcon);
            cnn.Open();
            SqlCommand cmd = new SqlCommand(query, cnn); //Query String
            var result = (Int32)cmd.ExecuteScalar();
            cnn.Close();
            return result;
        }
        public string _query_scalar_string(string query)
        {
            string dbcon = config.GetConnectionString("Constr");
            SqlConnection cnn = new SqlConnection(dbcon);
            cnn.Open();
            SqlCommand cmd = new SqlCommand(query, cnn); //Query String
            var result = (String)cmd.ExecuteScalar();
            cnn.Close();
            return result;
        }

        public Double _query_scalar_double(string query)
        {
            string dbcon = config.GetConnectionString("Constr");
            SqlConnection cnn = new SqlConnection(dbcon);
            cnn.Open();
            SqlCommand cmd = new SqlCommand(query, cnn); //Query String
            var result = (Double)cmd.ExecuteScalar();
            cnn.Close();
            return result;
        }
        public Decimal _query_scalar_decimal(string query)
        {
            string dbcon = config.GetConnectionString("Constr");
            SqlConnection cnn = new SqlConnection(dbcon);
            cnn.Open();
            SqlCommand cmd = new SqlCommand(query, cnn); //Query String
            var result = (Decimal)cmd.ExecuteScalar();
            cnn.Close();
            return result;
        }

        //** Post: Query **//
        public String _query_post(string query)
        {
            var result = "";
            string dbcon = config.GetConnectionString("Constr");
            SqlConnection cnn = new SqlConnection(dbcon);
            SqlCommand cmd = new SqlCommand(query, cnn); //Query String
            cnn.Open();
            try
            {
                cmd.ExecuteNonQuery();
                result = "OK";
            }
            catch (Exception e)
            {
                result = e.ToString();
            }
            cnn.Close();

            return result;
        }
        //*** Get: Store ปกติ ***//
        public JsonResult _sp(string query)
        {
            string dbcon = config.GetConnectionString("Constr");
            SqlConnection cnn = new SqlConnection(dbcon);
            cnn.Open();
            SqlCommand cmd = new SqlCommand(query, cnn); //Query String
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            DataSet dataset = new DataSet();
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(dataset);

            cnn.Close();
            dt = dataset.Tables[0];
            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.ColumnName, dr[col].ToString());
                }
                rows.Add(row);
            }
            cnn.Close();
            return Json(rows);
        }
        //*** Get: Store แบบมี param 1 ***//
        public JsonResult _sp_param1(string query, string param1)
        {
            string dbcon = config.GetConnectionString("Constr");
            SqlConnection cnn = new SqlConnection(dbcon);
            cnn.Open();
            SqlCommand cmd = new SqlCommand(query, cnn); //Query String
            cmd.Parameters.AddWithValue("@param1", param1);
            cmd.CommandType = CommandType.StoredProcedure;
            DataSet dataset = new DataSet();
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(dataset);
            cnn.Close();
            dt = dataset.Tables[0];
            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.ColumnName, dr[col].ToString());
                }
                rows.Add(row);
            }
            cnn.Close();
            return Json(rows);
        }
        //*** Get: Store แบบมี param 2 ***//
        public JsonResult _sp_param2(string query, string param1, string param2)
        {
            string dbcon = config.GetConnectionString("Constr");
            SqlConnection cnn = new SqlConnection(dbcon);
            cnn.Open();
            SqlCommand cmd = new SqlCommand(query, cnn); //Query String
            cmd.Parameters.AddWithValue("@param1", param1);
            cmd.Parameters.AddWithValue("@param2", param2);
            cmd.CommandType = CommandType.StoredProcedure;
            DataSet dataset = new DataSet();
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(dataset);
            cnn.Close();
            dt = dataset.Tables[0];
            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.ColumnName, dr[col].ToString());
                }
                rows.Add(row);
            }
            cnn.Close();
            return Json(rows);
        }
        //*** Get: Store แบบมี param 3 ***//
        public JsonResult _sp_param3(string query, string param1, string param2, string param3)
        {
            string dbcon = config.GetConnectionString("Constr");
            SqlConnection cnn = new SqlConnection(dbcon);
            cnn.Open();
            SqlCommand cmd = new SqlCommand(query, cnn); //Query String
            cmd.Parameters.AddWithValue("@param1", param1);
            cmd.Parameters.AddWithValue("@param2", param2);
            cmd.Parameters.AddWithValue("@param3", param3);
            cmd.CommandType = CommandType.StoredProcedure;
            DataSet dataset = new DataSet();
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(dataset);
            cnn.Close();
            dt = dataset.Tables[0];
            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.ColumnName, dr[col].ToString());
                }
                rows.Add(row);
            }
            cnn.Close();
            return Json(rows);
        }
        //*** Get: Store แบบมี param 4 ***//
        public JsonResult _sp_param4(string query, string param1, string param2, string param3, string param4)
        {
            string dbcon = config.GetConnectionString("Constr");
            SqlConnection cnn = new SqlConnection(dbcon);
            cnn.Open();
            SqlCommand cmd = new SqlCommand(query, cnn); //Query String
            cmd.Parameters.AddWithValue("@param1", param1);
            cmd.Parameters.AddWithValue("@param2", param2);
            cmd.Parameters.AddWithValue("@param3", param3);
            cmd.Parameters.AddWithValue("@param4", param4);
            cmd.CommandType = CommandType.StoredProcedure;
            DataSet dataset = new DataSet();
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(dataset);
            cnn.Close();
            dt = dataset.Tables[0];

            var _json = ConvertJson(dt);
            return _json;
        }
        //*** Get: Store แบบมี param 5 ***//
        public JsonResult _sp_param4(string query, string param1, string param2, string param3, string param4, string param5)
        {
            string dbcon = config.GetConnectionString("Constr");
            SqlConnection cnn = new SqlConnection(dbcon);
            cnn.Open();
            SqlCommand cmd = new SqlCommand(query, cnn); //Query String
            cmd.Parameters.AddWithValue("@param1", param1);
            cmd.Parameters.AddWithValue("@param2", param2);
            cmd.Parameters.AddWithValue("@param3", param3);
            cmd.Parameters.AddWithValue("@param4", param4);
            cmd.Parameters.AddWithValue("@param5", param5);
            cmd.CommandType = CommandType.StoredProcedure;
            DataSet dataset = new DataSet();
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(dataset);
            cnn.Close();
            dt = dataset.Tables[0];

            var _json = ConvertJson(dt);
            return _json;
        }
        //*** Get: Store แบบมี param 6 ***//
        public JsonResult _sp_param6(string query, string param1, string param2, string param3, string param4, string param5, string param6)
        {
            string dbcon = config.GetConnectionString("Constr");
            SqlConnection cnn = new SqlConnection(dbcon);
            cnn.Open();
            SqlCommand cmd = new SqlCommand(query, cnn); //Query String
            cmd.Parameters.AddWithValue("@param1", param1);
            cmd.Parameters.AddWithValue("@param2", param2);
            cmd.Parameters.AddWithValue("@param3", param3);
            cmd.Parameters.AddWithValue("@param4", param4);
            cmd.Parameters.AddWithValue("@param5", param5);
            cmd.Parameters.AddWithValue("@param6", param6);
            cmd.CommandType = CommandType.StoredProcedure;
            DataSet dataset = new DataSet();
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(dataset);
            cnn.Close();
            dt = dataset.Tables[0];

            var _json = ConvertJson(dt);
            return _json;
        }

        //*** Get: Store แบบมี out put ***//
        public JsonResult _sp_param_out(string query, string param1)
        {
            string dbcon = config.GetConnectionString("Constr");
            SqlConnection cnn = new SqlConnection(dbcon);
            cnn.Open();
            SqlCommand cmd = new SqlCommand(query, cnn); //Query String
            cmd.Parameters.AddWithValue("@param1", param1);
            cmd.CommandType = CommandType.StoredProcedure;
            DataSet dataset = new DataSet();
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(dataset);
            cnn.Close();
            dt = dataset.Tables[0];
            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.ColumnName, dr[col].ToString());
                }
                rows.Add(row);
            }
            cnn.Close();
            return Json(rows);
        }


        //*** Post: Store แบบมี param 1 ***//
        public String _post_param1(string query, string param1)
        {
            var result = "";
            try
            {
                string dbcon = config.GetConnectionString("Constr");
                SqlConnection cnn = new SqlConnection(dbcon);
                cnn.Open();
                SqlCommand cmd = new SqlCommand(query, cnn); //Query String
                cmd.Parameters.AddWithValue("@param1", param1);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.ExecuteNonQuery();
                cnn.Close();
                result = "OK";
            }
            catch (Exception e)
            {
                result = e.ToString();
            }
            return result;
        }
        //*** Post: Store แบบมี param 2 ***//
        public String _post_param2(string query, string param1, string param2)
        {
            var result = "";
            try
            {
                string dbcon = config.GetConnectionString("Constr");
                SqlConnection cnn = new SqlConnection(dbcon);
                cnn.Open();
                SqlCommand cmd = new SqlCommand(query, cnn); //Query String
                cmd.Parameters.AddWithValue("@param1", param1);
                cmd.Parameters.AddWithValue("@param2", param2);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.ExecuteNonQuery();
                cnn.Close();
                result = "OK";
            }
            catch (Exception e)
            {
                result = e.ToString();
            }
            return result;
        }
        //*** Post: Store แบบมี param 3 ***//
        public String _post_param3(string query, string param1, string param2, string param3)
        {
            var result = "";
            try
            {
                string dbcon = config.GetConnectionString("Constr");
                SqlConnection cnn = new SqlConnection(dbcon);
                cnn.Open();
                SqlCommand cmd = new SqlCommand(query, cnn); //Query String
                cmd.Parameters.AddWithValue("@param1", param1);
                cmd.Parameters.AddWithValue("@param2", param2);
                cmd.Parameters.AddWithValue("@param3", param3);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.ExecuteNonQuery();
                cnn.Close();
                result = "OK";
            }
            catch (Exception e)
            {
                result = e.ToString();
            }
            return result;
        }
        //*** Post: Store แบบมี param 4 ***//
        public String _post_param4(string query, string param1, string param2, string param3, string param4)
        {
            var result = "";
            try
            {
                string dbcon = config.GetConnectionString("Constr");
                SqlConnection cnn = new SqlConnection(dbcon);
                cnn.Open();
                SqlCommand cmd = new SqlCommand(query, cnn); //Query String
                cmd.Parameters.AddWithValue("@param1", param1);
                cmd.Parameters.AddWithValue("@param2", param2);
                cmd.Parameters.AddWithValue("@param3", param3);
                cmd.Parameters.AddWithValue("@param4", param4);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.ExecuteNonQuery();
                cnn.Close();
                result = "OK";
            }
            catch (Exception e)
            {
                result = e.ToString();
            }
            return result;
        }
        //*** Post: Store แบบมี param 4 ***//
        public String _post_param5(string query, string param1, string param2, string param3, string param4, string param5)
        {
            var result = "";
            try
            {
                string dbcon = config.GetConnectionString("Constr");
                SqlConnection cnn = new SqlConnection(dbcon);
                cnn.Open();
                SqlCommand cmd = new SqlCommand(query, cnn); //Query String
                cmd.Parameters.AddWithValue("@param1", param1);
                cmd.Parameters.AddWithValue("@param2", param2);
                cmd.Parameters.AddWithValue("@param3", param3);
                cmd.Parameters.AddWithValue("@param4", param4);
                cmd.Parameters.AddWithValue("@param5", param5);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.ExecuteNonQuery();
                cnn.Close();
                result = "OK";
            }
            catch (Exception e)
            {
                result = e.ToString();
            }
            return result;
        }

        //** Specail **//
        public FileResult _export(string query, string param1, string view)
        {
            string dbcon = config.GetConnectionString("Constr");
            SqlConnection cnn = new SqlConnection(dbcon);
            SqlCommand cmd = new SqlCommand();
            DataSet dataset = new DataSet();
            DataTable dt = new DataTable();

            cmd.Connection = cnn;
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.CommandText = query;
            cmd.Parameters.Add(new SqlParameter("@param1", param1));

            cnn.Open();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(dataset);
            cnn.Close();
            dt = dataset.Tables[0];

            var D = System.DateTime.Now.Date;
            var M = System.DateTime.Now.Month;
            var Y = System.DateTime.Now.Year;

            using (XLWorkbook wb = new XLWorkbook())
            {
                wb.Worksheets.Add(dt);
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Spare Part.xlsx");
                }
            }
            //return View(view);
        }

        public DataTable _sp_dt(string query)
        {
            string dbcon = config.GetConnectionString("Constr");
            SqlConnection cnn = new SqlConnection(dbcon);
            cnn.Open();
            SqlCommand cmd = new SqlCommand(query, cnn); //Query String
            cmd.CommandType = CommandType.StoredProcedure;
            DataSet dataset = new DataSet();
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(dataset);
            dt = dataset.Tables[0];
            cnn.Close();
            return dt;
        }
        public DataTable _sp_dt_param1(string query, string param1)
        {
            string dbcon = config.GetConnectionString("Constr");
            SqlConnection cnn = new SqlConnection(dbcon);
            cnn.Open();
            SqlCommand cmd = new SqlCommand(query, cnn); //Query String
            cmd.Parameters.AddWithValue("@param1", param1);
            cmd.CommandType = CommandType.StoredProcedure;
            DataSet dataset = new DataSet();
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(dataset);
            dt = dataset.Tables[0];

            cnn.Close();
            return dt;
        }
        public DataTable _sp_dt_param2(string query, string param1, string param2)
        {
            string dbcon = config.GetConnectionString("Constr");
            SqlConnection cnn = new SqlConnection(dbcon);
            cnn.Open();
            SqlCommand cmd = new SqlCommand(query, cnn); //Query String
            cmd.Parameters.AddWithValue("@param1", param1);
            cmd.Parameters.AddWithValue("@param2", param2);
            cmd.CommandType = CommandType.StoredProcedure;
            DataSet dataset = new DataSet();
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(dataset);
            dt = dataset.Tables[0];

            cnn.Close();
            return dt;
        }
        public DataTable _sp_dt_param3(string query, string param1, string param2, string param3)
        {
            string dbcon = config.GetConnectionString("Constr");
            SqlConnection cnn = new SqlConnection(dbcon);
            cnn.Open();
            SqlCommand cmd = new SqlCommand(query, cnn); //Query String
            cmd.Parameters.AddWithValue("@param1", param1);
            cmd.Parameters.AddWithValue("@param2", param2);
            cmd.Parameters.AddWithValue("@param3", param3);
            cmd.CommandType = CommandType.StoredProcedure;
            DataSet dataset = new DataSet();
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(dataset);
            dt = dataset.Tables[0];
            cnn.Close();
            return dt;
        }
        public DataTable _sp_dt_param4(string query, string param1, string param2, string param3, string param4)
        {
            string dbcon = config.GetConnectionString("Constr");
            SqlConnection cnn = new SqlConnection(dbcon);
            cnn.Open();
            SqlCommand cmd = new SqlCommand(query, cnn); //Query String
            cmd.Parameters.AddWithValue("@param1", param1);
            cmd.Parameters.AddWithValue("@param2", param2);
            cmd.Parameters.AddWithValue("@param4", param4);
            cmd.CommandType = CommandType.StoredProcedure;
            DataSet dataset = new DataSet();
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(dataset);
            dt = dataset.Tables[0];
            cnn.Close();
            return dt;
        }
        public DataTable _sp_dt_param5(string query, string param1, string param2, string param3, string param4, string param5)
        {
            string dbcon = config.GetConnectionString("Constr");
            SqlConnection cnn = new SqlConnection(dbcon);
            cnn.Open();
            SqlCommand cmd = new SqlCommand(query, cnn); //Query String
            cmd.Parameters.AddWithValue("@param1", param1);
            cmd.Parameters.AddWithValue("@param2", param2);
            cmd.Parameters.AddWithValue("@param4", param4);
            cmd.Parameters.AddWithValue("@param5", param5);
            cmd.CommandType = CommandType.StoredProcedure;
            DataSet dataset = new DataSet();
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(dataset);
            dt = dataset.Tables[0];
            cnn.Close();
            return dt;
        }
        public DataTable _sp_dt_param6(string query, string param1, string param2, string param3, string param4, string param5, string param6)
        {
            string dbcon = config.GetConnectionString("Constr");
            SqlConnection cnn = new SqlConnection(dbcon);
            cnn.Open();
            SqlCommand cmd = new SqlCommand(query, cnn); //Query String
            cmd.Parameters.AddWithValue("@param1", param1);
            cmd.Parameters.AddWithValue("@param2", param2);
            cmd.Parameters.AddWithValue("@param4", param4);
            cmd.Parameters.AddWithValue("@param5", param5);
            cmd.Parameters.AddWithValue("@param6", param6);
            cmd.CommandType = CommandType.StoredProcedure;
            DataSet dataset = new DataSet();
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(dataset);
            dt = dataset.Tables[0];
            cnn.Close();
            return dt;
        }
        public DataTable _query_dt(string query)
        {
            DataTable dt = new DataTable();
            string dbcon = config.GetConnectionString("Constr");
            using (SqlConnection cnn = new SqlConnection(dbcon))
            {
                cnn.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter(query, cnn);
                sqlDa.Fill(dt);
                cnn.Close();
            }
            return dt;
        }
    }
}
