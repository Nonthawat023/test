﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SF80_FAC_Dashboard_MVC.Models
{
    public class EnergyModel
    {
        public int[] gaugeArea { get; set; }

    }
}
