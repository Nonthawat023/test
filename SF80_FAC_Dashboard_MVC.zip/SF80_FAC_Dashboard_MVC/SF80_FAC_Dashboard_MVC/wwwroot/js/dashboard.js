﻿$(document).ready(function () {
    //$('[data-bs-toggle="popover"]').popover({ html: true});
    $('#LB1_FG').popover({
        html: true, title: '<div class="text-center">FG</div>', content: $('#POPB1_FG').html($('#POPB1_FG').html())
    });
    $('#LB1_WH').popover({
        html: true, title: '<div class="text-center">W/H</div>', content: $('#POPB1_WH').html($('#POPB1_WH').html())
    });
    $('#LB1_1K').popover({
        html: true, title: '<div class="text-center">B1 1K</div>', content: $('#POPB1_1K').html($('#POPB1_1K').html())
    });
    $('#LB1_10K').popover({
        html: true, title: '<div class="text-center">B1 10K</div>', content: $('#POPB1_10K').html($('#POPB1_10K').html())
    });
    $('#LB1_B2P1').popover({
        html: true, title: '<div class="text-center">B2 Point 1</div>', content: $('#POPB1_B2P1').html($('#POPB1_B2P1').html())
    });
    $('#LB1_B2P2').popover({
        html: true, title: '<div class="text-center">B2 Point 2</div>', content: $('#POPB1_B2P2').html($('#POPB1_B2P2').html())
    });
    $('#LB1_B3P1').popover({
        html: true, title: '<div class="text-center">B3 Point 1</div>', content: $('#POPB1_B3P1').html($('#POPB1_B3P1').html())
    });
    $('#LB1_B3P2').popover({
        html: true, title: '<div class="text-center">B3 Point 2</div>', content: $('#POPB1_B3P2').html($('#POPB1_B3P2').html())
    });
    $('#LB1_B4P1').popover({
        html: true, title: '<div class="text-center">B4 Point 1</div>', content: $('#POPB1_B4P1').html($('#POPB1_B4P1').html())
    });
    $('#LB1_B4P2').popover({
        html: true, title: '<div class="text-center">B4 Point 2</div>', content: $('#POPB1_B4P2').html($('#POPB1_B4P2').html())
    });
    $('#LB1_B41').popover({
        html: true, title: '<div class="text-center">B4-1</div>', content: $('#POPB1_B41').html($('#POPB1_B41').html())
    });

    $('#LB2_SP1').popover({
        html: true, title: '<div class="text-center">SPECIFIC Point 1</div>', content: $('#POPB2_SP1').html($('#POPB2_SP1').html())
    });
    $('#LB2_SP2').popover({
        html: true, title: '<div class="text-center">SPECIFIC Point 2</div>', content: $('#POPB2_SP2').html($('#POPB2_SP2').html())
    });
    $('#LB2_SP3').popover({
        html: true, title: '<div class="text-center">SPECIFIC Point 3</div>', content: $('#POPB2_SP3').html($('#POPB2_SP3').html())
    });
    $('#LB2_SP4').popover({
        html: true, title: '<div class="text-center">SPECIFIC Point 4</div>', content: $('#POPB2_SP4').html($('#POPB2_SP4').html())
    });
    $('#LB2_FG').popover({
        html: true, title: '<div class="text-center">FG</div>', content: $('#POPB2_FG').html($('#POPB2_FG').html())
    });
    $('#LB2_ABC').popover({
        html: true, title: '<div class="text-center">ABC W/H</div>', content: $('#POPB2_ABC').html($('#POPB2_ABC').html())
    });
    $('#LB2_Real').popover({
        html: true, title: '<div class="text-center">REALIBILITY</div>', content: $('#POPB2_Real').html($('#POPB2_Real').html())
    });
    $('#LB2_QAT').popover({
        html: true, title: '<div class="text-center">QAT Room</div>', content: $('#POPB2_QAT').html($('#POPB2_QAT').html())
    });

    //var obs = lamp.db_data2[0]
    //document.getElementById('LB2_SP1').addEventListener('mouseover', function () {
    //    //document.getElementById('temp_B2_SP1').innerHTML = obs['Temp_SP_1']
    //    //document.getElementsByClassName("popover-body")[0].innerHTML = obs['Temp_SP_1'];
    //    console.log(obs)
    //});
});


