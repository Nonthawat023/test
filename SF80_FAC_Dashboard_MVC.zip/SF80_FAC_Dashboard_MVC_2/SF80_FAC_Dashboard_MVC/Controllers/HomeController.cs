﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SF80_FAC_Dashboard_MVC.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;


namespace SF80_FAC_Dashboard_MVC.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly QueryController _qr;
        private readonly IConfiguration config;

        public HomeController(ILogger<HomeController> logger, QueryController _qr, IConfiguration config)
        {
            _logger = logger;
            this._qr = _qr;
            this.config = config;
        }

        public IActionResult Index()
        {
            var valuesGaugeA1_1 = GetUtilityA1_1();
            var valuesGaugeA1_2 = GetUtilityA1_2();
            var valuesGaugeA1_3 = GetUtilityA1_3();
            var valuesGaugeA1_4 = GetUtilityA1_4();
            var valuesGaugeA1_5 = GetUtilityA1_5();
            var valuesGaugeA1_6 = GetUtilityA1_6();
            var valuesGaugeA1_7 = GetUtilityA1_7();
            var valuesGaugeA1_8 = GetUtilityA1_8();


            ViewData["valuesGaugeA1_1"] = JsonConvert.SerializeObject(valuesGaugeA1_1);
            ViewData["valuesGaugeA1_2"] = JsonConvert.SerializeObject(valuesGaugeA1_2);
            ViewData["valuesGaugeA1_3"] = JsonConvert.SerializeObject(valuesGaugeA1_3);
            ViewData["valuesGaugeA1_4"] = JsonConvert.SerializeObject(valuesGaugeA1_4);
            ViewData["valuesGaugeA1_5"] = JsonConvert.SerializeObject(valuesGaugeA1_5);
            ViewData["valuesGaugeA1_6"] = JsonConvert.SerializeObject(valuesGaugeA1_6);
            ViewData["valuesGaugeA1_7"] = JsonConvert.SerializeObject(valuesGaugeA1_7);
            ViewData["valuesGaugeA1_8"] = JsonConvert.SerializeObject(valuesGaugeA1_8);


            return View();
        }
        #region All Gauge
        public decimal GetUtilityA1_1()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F8, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        public decimal GetUtilityA1_2()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F11, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        public decimal GetUtilityA1_3()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F21, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        public decimal GetUtilityA1_4()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F22, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        public decimal GetUtilityA1_5()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F10, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        public decimal GetUtilityA1_6()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F12, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        public decimal GetUtilityA1_7()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F22, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        public decimal GetUtilityA1_8()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F22, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        public decimal GetUtilityA1_9()
        {
            var data = _qr._query_scalar_decimal(@"SP_Get_Utility F22, TBL_FacilityReport_Utility_Supply");
            return data;
        }
        #endregion
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
