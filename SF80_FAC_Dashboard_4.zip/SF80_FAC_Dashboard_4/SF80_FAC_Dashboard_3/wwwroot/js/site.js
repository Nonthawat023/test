﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.


var firstTable = new Vue({
    el: '#firstTable',
    data: {
        rows: [
            { id: 1, name: "Chandler Bing", phone: '305-917-1301', profession: 'IT Manager' },
            { id: 2, name: "Ross Geller", phone: '210-684-8953', profession: 'Paleontologist' },
            { id: 3, name: "Rachel Green", phone: '765-338-0312', profession: 'Waitress' },
            { id: 4, name: "Monica Geller", phone: '714-541-3336', profession: 'Head Chef' },
            { id: 5, name: "Joey Tribbiani", phone: '972-297-6037', profession: 'Actor' },
            { id: 6, name: "Phoebe Buffay", phone: '760-318-8376', profession: 'Masseuse' }
        ]
    }
});





FusionCharts.ready(function () {
    new FusionCharts({
        type: "realtimecolumn",
        id: "salesticker",
        renderAt: "chart-container",
        width: "600",
        height: "400",
        dataFormat: "json",
        dataSource: {
            chart: {
                caption: "Products Sold Per Second",
                subCaption: "Gibzal Online",
                showrealtimevalue: "0",
                numdisplaysets: "10",
                theme: "fusion",
                labeldisplay: "rotate",
                showValues: "1",
                placeValuesInside: "0",
                plotToolText: "<b>$label</b><br>Products Sold: <b>$dataValue</b>"
            },
            categories: [
                {
                    category: [
                        {
                            label: "Start"
                        }
                    ]
                }
            ],
            dataset: [
                {
                    seriesname: "",
                    alpha: "100",
                    data: [
                        {
                            value: "12"
                        }
                    ]
                }
            ]
        },
        events: {
            initialized: function (evt, arg) {
                var chartRef = evt.sender;
                //Format minutes, seconds by adding 0 prefix accordingly
                function formatTime(time) {
                    time < 10 ? (time = "0" + time) : (time = time);
                    return time;
                }
                //Update Data method
                function updateData() {
                    //We need to create a querystring format incremental update, containing
                    //label in hh:mm:ss format and a value (random).
                    var currDate = new Date(),
                        label =
                            formatTime(currDate.getHours()) +
                            ":" +
                            formatTime(currDate.getMinutes()) +
                            ":" +
                            formatTime(currDate.getSeconds()),
                        //Get random number between 1 & 5 - rounded
                        transactions = Math.round(Math.random() * 19) + 1,
                        strData = "&label=" + label + "&value=" + transactions;

                    //Feed it to chart.
                    chartRef.feedData(strData);
                }

                chartRef.intervalUpdateId = setInterval(updateData, 1000);
            },

            disposed: function (evt, args) {
                clearInterval(evt.sender.intervalUpdateId);
            }
        }
    }).render();
});

