﻿//namespace SF80_FAC_Dashboard_3.Controllers
//{
//    public class Params
//    {
//        internal object param1;
//        internal object param2;
//        internal object param3;
//    }
//}