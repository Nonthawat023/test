﻿using Microsoft.AspNetCore.Mvc;
using SF80_FAC_Dashboard_3.Models;
using System.Diagnostics;
using System;
using Microsoft.Extensions.Logging;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
//using SF80_FAC_Dashboard_3.Models;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;
using System.Data;
using ClosedXML.Excel;

namespace SF80_FAC_Dashboard_3.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly QueryController _qr;
        private readonly IConfiguration config;

        public HomeController(ILogger<HomeController> logger, QueryController _qr, IConfiguration config)
        {
            _logger = logger;
            this._qr = _qr;
            this.config = config;
        }

        public class Params
        {
            internal object param1;
            internal object param2;
            internal object param3;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult IncreaseAndDecrease()
        {
            return View();
        }
        public IActionResult DB2()
        {
            return View();
        }
        public IActionResult Chart2()
        {
            return View();
        }
        public IActionResult chartDB()
        {
            return View();
        }
        public IActionResult Mainmenu()
        {
            return View();
        }
        public IActionResult UtilitySupply()
        {
            return View();
        }
        public IActionResult Manpower()
        {
            return View();
        }
        public IActionResult Sensor()
        {
            return View();
        }
        public IActionResult Electric()
        {
            return View();
        }

        [HttpPost]
        
        public IActionResult Chart()
        {
            return View();
        }
        public IActionResult ImageArea()
        {
            return View();
        }
        [HttpPost]
        public string UpdateDB([FromBody] Params param)
        {
            string ID = param.param1.ToString();
            string Name = param.param2.ToString();
            string Flag = param.param3.ToString();


            var data = _qr._query("Exec spPatchara '" + ID + "', '" + Name + "', '" + Flag + "' ");

            return "OK";
        }
        public JsonResult GetDB()
        {
            var data = _qr._query("SELECT * FROM tbNAME_Patchara");
            return data;
        }


        public JsonResult GetDB3()
        {
            var data = _qr._query("SELECT TOP (5) * FROM tbMonthlyPlan");
            return data;
        }

        public JsonResult GetDB4()
        {
            //var data = _qr._query("SELECT TOP (1) [Items],[May_BGT_Plan] FROM tbDash_T4_SumPlan");
            var data = _qr._query("SELECT TOP 5 * FROM tbDash_T4_SumPlan");
            return data;
        }
        [HttpPost]
        public IActionResult export(string SerialID)
        {
            string dbcon = config.GetConnectionString("Constr");
            SqlConnection cnn = new SqlConnection(dbcon);
            SqlCommand cmd = new SqlCommand();
            DataSet dataset = new DataSet();
            DataTable dt = new DataTable();

            cmd.Connection = cnn;
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.CommandText = "Exec store";
            cmd.Parameters.Add(new SqlParameter("@SerialID", SerialID));

            cnn.Open();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(dataset);
            cnn.Close();
            dt = dataset.Tables[0];

            using (XLWorkbook wb = new XLWorkbook())
            {
                wb.Worksheets.Add(dt);
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "MyFile.xlsx");
                }
            }
        }

        public JsonResult GetDataBarChart()
        {
            var data = _qr._query(@"Exec sp_Training_BarChart");
            return data;
        }
        //public JsonResult GetDataBarChart()
        //{
        //    var data = _qr._query("SELECT TOP (5) * FROM sp_Training_BarChart");
        //    return data;
        //}
        public JsonResult GetDataBarChart2()
        {
            var data = _qr._query(@"Exec sp_Training_BarChart2");
            return data;
        }
        public JsonResult GetInputProgress()
        {
            var data = _qr._query(@"Exec sp_DProduct_Progress 'Input','IS' ");
            return data;
        }
        public JsonResult GetMCTotalStatus()
        {
            var data = _qr._query(@"Exec sp_DMachine_TotalStatus 'Input','IS' ");
            return data;
        }
        public JsonResult GetCustomerZone()
        {
            var data = _qr._query(@"Exec sp_DCustmr_CustomerZone");
            return data;
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}