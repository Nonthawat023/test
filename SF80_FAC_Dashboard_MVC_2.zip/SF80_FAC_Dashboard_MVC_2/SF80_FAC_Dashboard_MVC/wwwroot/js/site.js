﻿//utility chart
window.feed = function (callback) {
    var tick = {};
    tick.plot0 = Math.ceil(350 + (Math.random() * 500));
    callback(JSON.stringify(tick));
};
var myConfig = {
    type: "gauge",
    globals: {
        fontSize: 10
    },
    plotarea: {
        marginTop: 3
    },
    plot: {
        size: '100%',
        valueBox: {
            placement: 'center',
            text: '%v', //default
            fontSize: 10,
            fontColor: 'black',
            rules: [{
                rule: '%v >= 566 && %v <= 850',
                text: '%v<br>Kgf/cm²'
            },
            {
                rule: '%v > 283 && %v < 566',
                text: '%v<br>Kgf/cm²'
            },
            //{
            //  rule: '%v < 640 && %v > 580',
            //  text: '%v<br>Fair'
            //},
            {
                rule: '%v <  283',
                text: '%v<br>Kgf/cm²'
            }
            ]
        }
    },
    tooltip: {
        borderRadius: 5
    },
    scaleR: {
        aperture: 180,
        minValue: 80,
        maxValue: 850,
        step: 50,
        center: {
            visible: false
        },
        tick: {
            visible: false
        },
        item: {
            offsetR: 0,
            rules: [{
                rule: '%i == 9',
                offsetX: 15
            }],
            //backgroundColor: 'black'
        },
        //labels: ['300', '', '', '', '', '', '580', '640', '700', '750', '', '850'],
        labels: [' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '],
        ring: {
            size: 7,
            rules: [{
                rule: '%v <= 283',
                backgroundColor: '#0AAB19'
            },
            {
                rule: '%v > 283 && %v < 566',
                backgroundColor: '#FFA726'
            },
            {
                rule: '%v >= 566 && %v <= 850',
                backgroundColor: '#E53935'
            },
                //{
                //  rule: '%v >= 700',
                //  backgroundColor: '#29B6F6'
                //}
            ]
        }
    },
    refresh: {
        type: "feed",
        transport: "js",
        url: "feed()",
        interval: 1500,
        resetTimeout: 1000
    },
    series: [{
        values: [282], // starting value
        backgroundColor: 'black',
        indicator: [-4, 0, 0, 0, 0.3],
        animation: {
            effect: 2,
            method: 1,
            sequence: 4,
            speed: 900
        },
    }]
};
zingchart.render({
    id: 'myChart',
    data: myConfig,
    height: 100,
    width: 100
});

//utility chart1
window.feed = function (callback) {
    var tick = {};
    tick.plot0 = Math.ceil(350 + (Math.random() * 500));
    callback(JSON.stringify(tick));
};
var myConfig = {
    type: "gauge",
    globals: {
        fontSize: 10
    },
    plotarea: {
        marginTop: 3
    },
    plot: {
        size: '100%',
        valueBox: {
            placement: 'center',
            text: '%v', //default
            fontSize: 10,
            fontColor: 'black',
            rules: [{
                rule: '%v >= 566 && %v <= 850',
                text: '%v<br>mm H2O'
            },
            {
                rule: '%v > 283 && %v < 566',
                text: '%v<br>mm H2O'
            },
            //{
            //  rule: '%v < 640 && %v > 580',
            //  text: '%v<br>Fair'
            //},
            {
                rule: '%v <  283',
                text: '%v<br>mm H2O'
            }
            ]
        }
    },
    tooltip: {
        borderRadius: 5
    },
    scaleR: {
        aperture: 180,
        minValue: 80,
        maxValue: 850,
        step: 50,
        center: {
            visible: false
        },
        tick: {
            visible: false
        },
        item: {
            offsetR: 0,
            rules: [{
                rule: '%i == 9',
                offsetX: 15
            }],
            //backgroundColor: 'black'
        },
        //labels: ['300', '', '', '', '', '', '580', '640', '700', '750', '', '850'],
        labels: [' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '],
        ring: {
            size: 7,
            rules: [{
                rule: '%v <= 283',
                backgroundColor: '#0AAB19'
            },
            {
                rule: '%v > 283 && %v < 566',
                backgroundColor: '#FFA726'
            },
            {
                rule: '%v >= 566 && %v <= 850',
                backgroundColor: '#E53935'
            },
                //{
                //  rule: '%v >= 700',
                //  backgroundColor: '#29B6F6'
                //}
            ]
        }
    },
    refresh: {
        type: "feed",
        transport: "js",
        url: "feed()",
        interval: 1500,
        resetTimeout: 1000
    },
    series: [{
        values: [282], // starting value
        backgroundColor: 'black',
        indicator: [-4, 0, 0, 0, 0.3],
        animation: {
            effect: 2,
            method: 1,
            sequence: 4,
            speed: 900
        },
    }]
};
zingchart.render({
    id: 'myChart1',
    data: myConfig,
    height: 100,
    width: 100
});

//utility chart2
window.feed = function (callback) {
    var tick = {};
    tick.plot0 = Math.ceil(350 + (Math.random() * 500));
    callback(JSON.stringify(tick));
};
var myConfig = {
    type: "gauge",
    globals: {
        fontSize: 10
    },
    plotarea: {
        marginTop: 3
    },
    plot: {
        size: '100%',
        valueBox: {
            placement: 'center',
            text: '%v', //default
            fontSize: 10,
            fontColor: 'black',
            rules: [{
                rule: '%v >= 566 && %v <= 850',
                text: '%v<br>Kgf/cm²'
            },
            {
                rule: '%v > 283 && %v < 566',
                text: '%v<br>Kgf/cm²'
            },
            //{
            //  rule: '%v < 640 && %v > 580',
            //  text: '%v<br>Fair'
            //},
            {
                rule: '%v <  283',
                text: '%v<br>Kgf/cm²'
            }
            ]
        }
    },
    tooltip: {
        borderRadius: 5
    },
    scaleR: {
        aperture: 180,
        minValue: 80,
        maxValue: 850,
        step: 50,
        center: {
            visible: false
        },
        tick: {
            visible: false
        },
        item: {
            offsetR: 0,
            rules: [{
                rule: '%i == 9',
                offsetX: 15
            }],
            //backgroundColor: 'black'
        },
        //labels: ['300', '', '', '', '', '', '580', '640', '700', '750', '', '850'],
        labels: [' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '],
        ring: {
            size: 7,
            rules: [{
                rule: '%v <= 283',
                backgroundColor: '#0AAB19'
            },
            {
                rule: '%v > 283 && %v < 566',
                backgroundColor: '#FFA726'
            },
            {
                rule: '%v >= 566 && %v <= 850',
                backgroundColor: '#E53935'
            },
                //{
                //  rule: '%v >= 700',
                //  backgroundColor: '#29B6F6'
                //}
            ]
        }
    },
    refresh: {
        type: "feed",
        transport: "js",
        url: "feed()",
        interval: 1500,
        resetTimeout: 1000
    },
    series: [{
        values: [282], // starting value
        backgroundColor: 'black',
        indicator: [-4, 0, 0, 0, 0.3],
        animation: {
            effect: 2,
            method: 1,
            sequence: 4,
            speed: 900
        },
    }]
};
zingchart.render({
    id: 'myChart2',
    data: myConfig,
    height: 100,
    width: 100
});

//utility chart3
window.feed = function (callback) {
    var tick = {};
    tick.plot0 = Math.ceil(350 + (Math.random() * 500));
    callback(JSON.stringify(tick));
};
var myConfig = {
    type: "gauge",
    globals: {
        fontSize: 10
    },
    plotarea: {
        marginTop: 3
    },
    plot: {
        size: '100%',
        valueBox: {
            placement: 'center',
            text: '%v', //default
            fontSize: 10,
            fontColor: 'black',
            rules: [{
                rule: '%v >= 566 && %v <= 850',
                text: '%v<br>°C'
            },
            {
                rule: '%v > 283 && %v < 566',
                text: '%v<br>°C'
            },
            //{
            //  rule: '%v < 640 && %v > 580',
            //  text: '%v<br>Fair'
            //},
            {
                rule: '%v <  283',
                text: '%v<br>°C'
            }
            ]
        }
    },
    tooltip: {
        borderRadius: 5
    },
    scaleR: {
        aperture: 180,
        minValue: 80,
        maxValue: 850,
        step: 50,
        center: {
            visible: false
        },
        tick: {
            visible: false
        },
        item: {
            offsetR: 0,
            rules: [{
                rule: '%i == 9',
                offsetX: 15
            }],
            //backgroundColor: 'black'
        },
        //labels: ['300', '', '', '', '', '', '580', '640', '700', '750', '', '850'],
        labels: [' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '],
        ring: {
            size: 7,
            rules: [{
                rule: '%v <= 283',
                backgroundColor: '#0AAB19'
            },
            {
                rule: '%v > 283 && %v < 566',
                backgroundColor: '#FFA726'
            },
            {
                rule: '%v >= 566 && %v <= 850',
                backgroundColor: '#E53935'
            },
                //{
                //  rule: '%v >= 700',
                //  backgroundColor: '#29B6F6'
                //}
            ]
        }
    },
    refresh: {
        type: "feed",
        transport: "js",
        url: "feed()",
        interval: 1500,
        resetTimeout: 1000
    },
    series: [{
        values: [282], // starting value
        backgroundColor: 'black',
        indicator: [-4, 0, 0, 0, 0.3],
        animation: {
            effect: 2,
            method: 1,
            sequence: 4,
            speed: 900
        },
    }]
};
zingchart.render({
    id: 'myChart3',
    data: myConfig,
    height: 100,
    width: 100
});

//utility chart4
window.feed = function (callback) {
    var tick = {};
    tick.plot0 = Math.ceil(350 + (Math.random() * 500));
    callback(JSON.stringify(tick));
};
var myConfig = {
    type: "gauge",
    globals: {
        fontSize: 10
    },
    plotarea: {
        marginTop: 3
    },
    plot: {
        size: '100%',
        valueBox: {
            placement: 'center',
            text: '%v', //default
            fontSize: 10,
            fontColor: 'black',
            rules: [{
                rule: '%v >= 566 && %v <= 850',
                text: '%v<br>Kgf/cm²'
            },
            {
                rule: '%v > 283 && %v < 566',
                text: '%v<br>Kgf/cm²'
            },
            //{
            //  rule: '%v < 640 && %v > 580',
            //  text: '%v<br>Fair'
            //},
            {
                rule: '%v <  283',
                text: '%v<br>Kgf/cm²'
            }
            ]
        }
    },
    tooltip: {
        borderRadius: 5
    },
    scaleR: {
        aperture: 180,
        minValue: 80,
        maxValue: 850,
        step: 50,
        center: {
            visible: false
        },
        tick: {
            visible: false
        },
        item: {
            offsetR: 0,
            rules: [{
                rule: '%i == 9',
                offsetX: 15
            }],
            //backgroundColor: 'black'
        },
        //labels: ['300', '', '', '', '', '', '580', '640', '700', '750', '', '850'],
        labels: [' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '],
        ring: {
            size: 7,
            rules: [{
                rule: '%v <= 283',
                backgroundColor: '#0AAB19'
            },
            {
                rule: '%v > 283 && %v < 566',
                backgroundColor: '#FFA726'
            },
            {
                rule: '%v >= 566 && %v <= 850',
                backgroundColor: '#E53935'
            },
                //{
                //  rule: '%v >= 700',
                //  backgroundColor: '#29B6F6'
                //}
            ]
        }
    },
    refresh: {
        type: "feed",
        transport: "js",
        url: "feed()",
        interval: 1500,
        resetTimeout: 1000
    },
    series: [{
        values: [282], // starting value
        backgroundColor: 'black',
        indicator: [-4, 0, 0, 0, 0.3],
        animation: {
            effect: 2,
            method: 1,
            sequence: 4,
            speed: 900
        },
    }]
};
zingchart.render({
    id: 'myChart4',
    data: myConfig,
    height: 100,
    width: 100
});

//utility chart5
window.feed = function (callback) {
    var tick = {};
    tick.plot0 = Math.ceil(350 + (Math.random() * 500));
    callback(JSON.stringify(tick));
};
var myConfig = {
    type: "gauge",
    globals: {
        fontSize: 10
    },
    plotarea: {
        marginTop: 3
    },
    plot: {
        size: '100%',
        valueBox: {
            placement: 'center',
            text: '%v', //default
            fontSize: 10,
            fontColor: 'black',
            rules: [{
                rule: '%v >= 566 && %v <= 850',
                text: '%v<br>°C'
            },
            {
                rule: '%v > 283 && %v < 566',
                text: '%v<br>°C'
            },
            //{
            //  rule: '%v < 640 && %v > 580',
            //  text: '%v<br>Fair'
            //},
            {
                rule: '%v <  283',
                text: '%v<br>°C'
            }
            ]
        }
    },
    tooltip: {
        borderRadius: 5
    },
    scaleR: {
        aperture: 180,
        minValue: 80,
        maxValue: 850,
        step: 50,
        center: {
            visible: false
        },
        tick: {
            visible: false
        },
        item: {
            offsetR: 0,
            rules: [{
                rule: '%i == 9',
                offsetX: 15
            }],
            //backgroundColor: 'black'
        },
        //labels: ['300', '', '', '', '', '', '580', '640', '700', '750', '', '850'],
        labels: [' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '],
        ring: {
            size: 7,
            rules: [{
                rule: '%v <= 283',
                backgroundColor: '#0AAB19'
            },
            {
                rule: '%v > 283 && %v < 566',
                backgroundColor: '#FFA726'
            },
            {
                rule: '%v >= 566 && %v <= 850',
                backgroundColor: '#E53935'
            },
                //{
                //  rule: '%v >= 700',
                //  backgroundColor: '#29B6F6'
                //}
            ]
        }
    },
    refresh: {
        type: "feed",
        transport: "js",
        url: "feed()",
        interval: 1500,
        resetTimeout: 1000
    },
    series: [{
        values: [282], // starting value
        backgroundColor: 'black',
        indicator: [-4, 0, 0, 0, 0.3],
        animation: {
            effect: 2,
            method: 1,
            sequence: 4,
            speed: 900
        },
    }]
};
zingchart.render({
    id: 'myChart5',
    data: myConfig,
    height: 100,
    width: 100
});

//utility chart6
window.feed = function (callback) {
    var tick = {};
    tick.plot0 = Math.ceil(350 + (Math.random() * 500));
    callback(JSON.stringify(tick));
};
var myConfig = {
    type: "gauge",
    globals: {
        fontSize: 10
    },
    plotarea: {
        marginTop: 3
    },
    plot: {
        size: '100%',
        valueBox: {
            placement: 'center',
            text: '%v', //default
            fontSize: 10,
            fontColor: 'black',
            rules: [{
                rule: '%v >= 566 && %v <= 850',
                text: '%v<br>Kgf/cm²'
            },
            {
                rule: '%v > 283 && %v < 566',
                text: '%v<br>Kgf/cm²'
            },
            //{
            //  rule: '%v < 640 && %v > 580',
            //  text: '%v<br>Fair'
            //},
            {
                rule: '%v <  283',
                text: '%v<br>Kgf/cm²'
            }
            ]
        }
    },
    tooltip: {
        borderRadius: 5
    },
    scaleR: {
        aperture: 180,
        minValue: 80,
        maxValue: 850,
        step: 50,
        center: {
            visible: false
        },
        tick: {
            visible: false
        },
        item: {
            offsetR: 0,
            rules: [{
                rule: '%i == 9',
                offsetX: 15
            }],
            //backgroundColor: 'black'
        },
        //labels: ['300', '', '', '', '', '', '580', '640', '700', '750', '', '850'],
        labels: [' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '],
        ring: {
            size: 7,
            rules: [{
                rule: '%v <= 283',
                backgroundColor: '#0AAB19'
            },
            {
                rule: '%v > 283 && %v < 566',
                backgroundColor: '#FFA726'
            },
            {
                rule: '%v >= 566 && %v <= 850',
                backgroundColor: '#E53935'
            },
                //{
                //  rule: '%v >= 700',
                //  backgroundColor: '#29B6F6'
                //}
            ]
        }
    },
    refresh: {
        type: "feed",
        transport: "js",
        url: "feed()",
        interval: 1500,
        resetTimeout: 1000
    },
    series: [{
        values: [282], // starting value
        backgroundColor: 'black',
        indicator: [-4, 0, 0, 0, 0.3],
        animation: {
            effect: 2,
            method: 1,
            sequence: 4,
            speed: 900
        },
    }]
};
zingchart.render({
    id: 'myChart6',
    data: myConfig,
    height: 100,
    width: 100
});

//utility chart7
window.feed = function (callback) {
    var tick = {};
    tick.plot0 = Math.ceil(350 + (Math.random() * 500));
    callback(JSON.stringify(tick));
};
var myConfig = {
    type: "gauge",
    globals: {
        fontSize: 10
    },
    plotarea: {
        marginTop: 3
    },
    plot: {
        size: '100%',
        valueBox: {
            placement: 'center',
            text: '%v', //default
            fontSize: 10,
            fontColor: 'black',
            rules: [{
                rule: '%v >= 566 && %v <= 850',
                text: '%v<br>mm H2O'
            },
            {
                rule: '%v > 283 && %v < 566',
                text: '%v<br>mm H2O'
            },
            //{
            //  rule: '%v < 640 && %v > 580',
            //  text: '%v<br>Fair'
            //},
            {
                rule: '%v <  283',
                text: '%v<br>mm H2O'
            }
            ]
        }
    },
    tooltip: {
        borderRadius: 5
    },
    scaleR: {
        aperture: 180,
        minValue: 80,
        maxValue: 850,
        step: 50,
        center: {
            visible: false
        },
        tick: {
            visible: false
        },
        item: {
            offsetR: 0,
            rules: [{
                rule: '%i == 9',
                offsetX: 15
            }],
            //backgroundColor: 'black'
        },
        //labels: ['300', '', '', '', '', '', '580', '640', '700', '750', '', '850'],
        labels: [' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '],
        ring: {
            size: 7,
            rules: [{
                rule: '%v <= 283',
                backgroundColor: '#0AAB19'
            },
            {
                rule: '%v > 283 && %v < 566',
                backgroundColor: '#FFA726'
            },
            {
                rule: '%v >= 566 && %v <= 850',
                backgroundColor: '#E53935'
            },
                //{
                //  rule: '%v >= 700',
                //  backgroundColor: '#29B6F6'
                //}
            ]
        }
    },
    refresh: {
        type: "feed",
        transport: "js",
        url: "feed()",
        interval: 1500,
        resetTimeout: 1000
    },
    series: [{
        values: [282], // starting value
        backgroundColor: 'black',
        indicator: [-4, 0, 0, 0, 0.3],
        animation: {
            effect: 2,
            method: 1,
            sequence: 4,
            speed: 900
        },
    }]
};
zingchart.render({
    id: 'myChart7',
    data: myConfig,
    height: 100,
    width: 100
});

//utility chart8
window.feed = function (callback) {
    var tick = {};
    tick.plot0 = Math.ceil(350 + (Math.random() * 500));
    callback(JSON.stringify(tick));
};
var myConfig = {
    type: "gauge",
    globals: {
        fontSize: 10
    },
    plotarea: {
        marginTop: 3
    },
    plot: {
        size: '100%',
        valueBox: {
            placement: 'center',
            text: '%v', //default
            fontSize: 10,
            fontColor: 'black',
            rules: [{
                rule: '%v >= 566 && %v <= 850',
                text: '%v<br>Kgf/cm²'
            },
            {
                rule: '%v > 283 && %v < 566',
                text: '%v<br>Kgf/cm²'
            },
            //{
            //  rule: '%v < 640 && %v > 580',
            //  text: '%v<br>Fair'
            //},
            {
                rule: '%v <  283',
                text: '%v<br>Kgf/cm²'
            }
            ]
        }
    },
    tooltip: {
        borderRadius: 5
    },
    scaleR: {
        aperture: 180,
        minValue: 80,
        maxValue: 850,
        step: 50,
        center: {
            visible: false
        },
        tick: {
            visible: false
        },
        item: {
            offsetR: 0,
            rules: [{
                rule: '%i == 9',
                offsetX: 15
            }],
            //backgroundColor: 'black'
        },
        //labels: ['300', '', '', '', '', '', '580', '640', '700', '750', '', '850'],
        labels: [' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '],
        ring: {
            size: 7,
            rules: [{
                rule: '%v <= 283',
                backgroundColor: '#0AAB19'
            },
            {
                rule: '%v > 283 && %v < 566',
                backgroundColor: '#FFA726'
            },
            {
                rule: '%v >= 566 && %v <= 850',
                backgroundColor: '#E53935'
            },
                //{
                //  rule: '%v >= 700',
                //  backgroundColor: '#29B6F6'
                //}
            ]
        }
    },
    refresh: {
        type: "feed",
        transport: "js",
        url: "feed()",
        interval: 1500,
        resetTimeout: 1000
    },
    series: [{
        values: [282], // starting value
        backgroundColor: 'black',
        indicator: [-4, 0, 0, 0, 0.3],
        animation: {
            effect: 2,
            method: 1,
            sequence: 4,
            speed: 900
        },
    }]
};
zingchart.render({
    id: 'myChart8',
    data: myConfig,
    height: 100,
    width: 100
});

//utility chart9
window.feed = function (callback) {
    var tick = {};
    tick.plot0 = Math.ceil(350 + (Math.random() * 500));
    callback(JSON.stringify(tick));
};
var myConfig = {
    type: "gauge",
    globals: {
        fontSize: 10
    },
    plotarea: {
        marginTop: 3
    },
    plot: {
        size: '100%',
        valueBox: {
            placement: 'center',
            text: '%v', //default
            fontSize: 10,
            fontColor: 'black',
            rules: [{
                rule: '%v >= 566 && %v <= 850',
                text: '%v<br>°C'
            },
            {
                rule: '%v > 283 && %v < 566',
                text: '%v<br>°C'
            },
            //{
            //  rule: '%v < 640 && %v > 580',
            //  text: '%v<br>Fair'
            //},
            {
                rule: '%v <  283',
                text: '%v<br>°C'
            }
            ]
        }
    },
    tooltip: {
        borderRadius: 5
    },
    scaleR: {
        aperture: 180,
        minValue: 80,
        maxValue: 850,
        step: 50,
        center: {
            visible: false
        },
        tick: {
            visible: false
        },
        item: {
            offsetR: 0,
            rules: [{
                rule: '%i == 9',
                offsetX: 15
            }],
            //backgroundColor: 'black'
        },
        //labels: ['300', '', '', '', '', '', '580', '640', '700', '750', '', '850'],
        labels: [' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '],
        ring: {
            size: 7,
            rules: [{
                rule: '%v <= 283',
                backgroundColor: '#0AAB19'
            },
            {
                rule: '%v > 283 && %v < 566',
                backgroundColor: '#FFA726'
            },
            {
                rule: '%v >= 566 && %v <= 850',
                backgroundColor: '#E53935'
            },
                //{
                //  rule: '%v >= 700',
                //  backgroundColor: '#29B6F6'
                //}
            ]
        }
    },
    refresh: {
        type: "feed",
        transport: "js",
        url: "feed()",
        interval: 1500,
        resetTimeout: 1000
    },
    series: [{
        values: [282], // starting value
        backgroundColor: 'black',
        indicator: [-4, 0, 0, 0, 0.3],
        animation: {
            effect: 2,
            method: 1,
            sequence: 4,
            speed: 900
        },
    }]
};
zingchart.render({
    id: 'myChart9',
    data: myConfig,
    height: 100,
    width: 100
});

//utility chart10
window.feed = function (callback) {
    var tick = {};
    tick.plot0 = Math.ceil(350 + (Math.random() * 500));
    callback(JSON.stringify(tick));
};
var myConfig = {
    type: "gauge",
    globals: {
        fontSize: 10
    },
    plotarea: {
        marginTop: 3
    },
    plot: {
        size: '100%',
        valueBox: {
            placement: 'center',
            text: '%v', //default
            fontSize: 10,
            fontColor: 'black',
            rules: [{
                rule: '%v >= 566 && %v <= 850',
                text: '%v<br>Kgf/cm²'
            },
            {
                rule: '%v > 283 && %v < 566',
                text: '%v<br>Kgf/cm²'
            },
            //{
            //  rule: '%v < 640 && %v > 580',
            //  text: '%v<br>Fair'
            //},
            {
                rule: '%v <  283',
                text: '%v<br>Kgf/cm²'
            }
            ]
        }
    },
    tooltip: {
        borderRadius: 5
    },
    scaleR: {
        aperture: 180,
        minValue: 80,
        maxValue: 850,
        step: 50,
        center: {
            visible: false
        },
        tick: {
            visible: false
        },
        item: {
            offsetR: 0,
            rules: [{
                rule: '%i == 9',
                offsetX: 15
            }],
            //backgroundColor: 'black'
        },
        //labels: ['300', '', '', '', '', '', '580', '640', '700', '750', '', '850'],
        labels: [' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '],
        ring: {
            size: 7,
            rules: [{
                rule: '%v <= 283',
                backgroundColor: '#0AAB19'
            },
            {
                rule: '%v > 283 && %v < 566',
                backgroundColor: '#FFA726'
            },
            {
                rule: '%v >= 566 && %v <= 850',
                backgroundColor: '#E53935'
            },
                //{
                //  rule: '%v >= 700',
                //  backgroundColor: '#29B6F6'
                //}
            ]
        }
    },
    refresh: {
        type: "feed",
        transport: "js",
        url: "feed()",
        interval: 1500,
        resetTimeout: 1000
    },
    series: [{
        values: [282], // starting value
        backgroundColor: 'black',
        indicator: [-4, 0, 0, 0, 0.3],
        animation: {
            effect: 2,
            method: 1,
            sequence: 4,
            speed: 900
        },
    }]
};
zingchart.render({
    id: 'myChart10',
    data: myConfig,
    height: 100,
    width: 100
});

//utility chart11
window.feed = function (callback) {
    var tick = {};
    tick.plot0 = Math.ceil(350 + (Math.random() * 500));
    callback(JSON.stringify(tick));
};
var myConfig = {
    type: "gauge",
    globals: {
        fontSize: 10
    },
    plotarea: {
        marginTop: 3
    },
    plot: {
        size: '100%',
        valueBox: {
            placement: 'center',
            text: '%v', //default
            fontSize: 10,
            fontColor: 'black',
            rules: [{
                rule: '%v >= 566 && %v <= 850',
                text: '%v<br>MΩ-cm'
            },
            {
                rule: '%v > 283 && %v < 566',
                text: '%v<br>MΩ-cm'
            },
            //{
            //  rule: '%v < 640 && %v > 580',
            //  text: '%v<br>Fair'
            //},
            {
                rule: '%v <  283',
                text: '%v<br>MΩ-cm'
            }
            ]
        }
    },
    tooltip: {
        borderRadius: 5
    },
    scaleR: {
        aperture: 180,
        minValue: 80,
        maxValue: 850,
        step: 50,
        center: {
            visible: false
        },
        tick: {
            visible: false
        },
        item: {
            offsetR: 0,
            rules: [{
                rule: '%i == 9',
                offsetX: 15
            }],
            //backgroundColor: 'black'
        },
        //labels: ['300', '', '', '', '', '', '580', '640', '700', '750', '', '850'],
        labels: [' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '],
        ring: {
            size: 7,
            rules: [{
                rule: '%v <= 283',
                backgroundColor: '#0AAB19'
            },
            {
                rule: '%v > 283 && %v < 566',
                backgroundColor: '#FFA726'
            },
            {
                rule: '%v >= 566 && %v <= 850',
                backgroundColor: '#E53935'
            },
                //{
                //  rule: '%v >= 700',
                //  backgroundColor: '#29B6F6'
                //}
            ]
        }
    },
    refresh: {
        type: "feed",
        transport: "js",
        url: "feed()",
        interval: 1500,
        resetTimeout: 1000
    },
    series: [{
        values: [282], // starting value
        backgroundColor: 'black',
        indicator: [-4, 0, 0, 0, 0.3],
        animation: {
            effect: 2,
            method: 1,
            sequence: 4,
            speed: 900
        },
    }]
};
zingchart.render({
    id: 'myChart11',
    data: myConfig,
    height: 100,
    width: 100
});


//pie1
anychart.onDocumentReady(function () {

    var color1 = "#26E10C";
    var color2 = "#CDCDC7";
    var color3 = "#9BEE0A";
    var color4 = "#37CC07";
    var color5 = "#16E0CE";
    var color6 = "#AFF4DA";
    var color7 = "#06F978";
    var color8 = "#529A4A";

    // Variable for controlling color enlightenment
    var colorIndex = 0;

    // color lightning function
    function colorizer() {
        var mixColor1 = anychart.color.lighten(color1, colorIndex);
        colorIndex = colorIndex + 0.2;
        return mixColor1;
    }


    // create data
    var data = [
        { x: "IS B-1 1K", value: 637166, fill: (colorizer()) },
        { x: "IS B-1 10K", value: 721630, fill: (color4) },
        { x: "IS & BMS B-2", value: 148662, fill: (color2) },
        { x: "HTPS & MOLED B-3", value: 78662, fill: (color3) },
        { x: "LSI B-4", value: 11234, fill: (color6) },
        { x: "SMOLED B#2", value: 34532, fill: (color7) },
        { x: "QAT B#2", value: 75326, fill: (color8) },
        { x: "SMOLED RELIBILITY", value: 23573, fill: (color5) }
    ];

    // create a 3d pie chart and set the data
    var chart = anychart.pie3d(data);


    // legend
    var legend = chart.legend();
    legend.enabled(true);

    // set position mode
    legend.positionMode("outside");
    // set position and alignement
    legend.position("right");
    legend.align("center");
    legend.itemsLayout("verticalExpandable");


    // set the chart title
    //chart.title("MFG");

    // set the container id
    chart.container("Energy1");


    // initiate drawing the chart
    chart.draw();

});
//pie2
