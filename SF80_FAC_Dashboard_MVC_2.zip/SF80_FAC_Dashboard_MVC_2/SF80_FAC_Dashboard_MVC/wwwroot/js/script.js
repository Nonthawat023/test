﻿window.feed = function (callback) {
    var tick = {};
    tick.plot0 = Math.ceil(350 + (Math.random() * 500));
    callback(JSON.stringify(tick));
};

var myConfig = {
    type: "gauge",
    globals: {
        fontSize: 10
    },
    plotarea: {
        marginTop: 60
    },
    plot: {
        size: '100%',
        valueBox: {
            placement: 'center',
            text: '%v', //default
            fontSize: 16,
            fontColor: 'black',
            rules: [{
                rule: '%v >= 566 && %v <= 850',
                text: '%v<br>Kgf/cm²'
            },
            {
                rule: '%v > 283 && %v < 566',
                text: '%v<br>Kgf/cm²'
            },
            //{
            //  rule: '%v < 640 && %v > 580',
            //  text: '%v<br>Fair'
            //},
            {
                rule: '%v <  283',
                text: '%v<br>Kgf/cm²'
            }
            ]
        }
    },
    tooltip: {
        borderRadius: 5
    },
    scaleR: {
        aperture: 180,
        minValue: 80,
        maxValue: 850,
        step: 50,
        center: {
            visible: false
        },
        tick: {
            visible: false
        },
        item: {
            offsetR: 0,
            rules: [{
                rule: '%i == 9',
                offsetX: 15
            }],
        },
        labels: [' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '],
        ring: {
            size: 40,
            rules: [{
                rule: '%v <= 283',
                backgroundColor: '#0AAB19'
            },
            {
                rule: '%v > 283 && %v < 566',
                backgroundColor: '#FFA726'
            },
            {
                rule: '%v >= 566 && %v <= 850',
                backgroundColor: '#E53935'
            },
                //{
                //  rule: '%v >= 700',
                //  backgroundColor: '#29B6F6'
                //}
            ]
        }
    },
    refresh: {
        type: "feed",
        transport: "js",
        url: "feed()",
        interval: 1500,
        resetTimeout: 1000
    },
    series: [{
        values: [282], // starting value
        backgroundColor: 'black',
        indicator: [-4, 0, 0, 0, 0.3],
        animation: {
            effect: 2,
            method: 1,
            sequence: 4,
            speed: 900
        },
    }]
};

zingchart.render({
    id: 'myChart',
    data: myConfig,
    height: 300,
    width: '100%'
});