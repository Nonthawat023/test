﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SF80_FAC_Dashboard_MVC.Controllers
{
    public class UtilityController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult UtilityB2()
        {
            return View();
        }
        public IActionResult UtilityDIW()
        {
            return View();
        }
        public IActionResult UtilityElectric()
        {
            return View();
        }
    }
}
