﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SF80_FAC_Dashboard_MVC.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace SF80_FAC_Dashboard_MVC.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly QueryController _qr;
        private readonly IConfiguration config;

        public HomeController(ILogger<HomeController> logger, QueryController _qr, IConfiguration config)
        {
            _logger = logger;
            this._qr = _qr;
            this.config = config;
        }

        public IActionResult Index()
        {
            return View();
        }
        public JsonResult GetDB()
        {
            var data = _qr._query("SELECT * FROM tbNAME_Patchara");
            return data;
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
