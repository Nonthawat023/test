﻿using Microsoft.AspNetCore.Mvc;
using SF80_FAC_Dashboard_MVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SF80_FAC_Dashboard_MVC.Controllers
{
    public class TempHumidityController : Controller
    {
        private readonly QueryController _qr;
        public TempHumidityController(QueryController _qr)
        {
            this._qr = _qr;
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult BuildingOne()
        {
            return View();
        }
        public IActionResult BuildingTwo()
        {
            return View();
        }

        
    }
}
