﻿using Microsoft.AspNetCore.Mvc;
using SF80_FAC_Dashboard_MVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SF80_FAC_Dashboard_MVC.Controllers
{
    public class TempHumidityController : Controller
    {
        private readonly QueryController _qr;
        public TempHumidityController(QueryController _qr)
        {
            this._qr = _qr;
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult BuildingOne()
        {
            return View();
        }
        public IActionResult BuildingTwo()
        {
            return View();
        }
        public IActionResult B1_1K()
        {
          
            return View();
        }
        public IActionResult B1B1_10K()
        {
            return View();
        }
        public IActionResult B1B2P1()
        {
            return View();
        }
        public IActionResult B1B2P2()
        {
            return View();
        }
        public IActionResult B1B3P1()
        {
            return View();
        }
        public IActionResult B1B3P2()
        {
            return View();
        }
        public IActionResult B1B4P1()
        {
            return View();
        }
        public IActionResult B1B4P2()
        {
            return View();
        }
        public IActionResult B1B4_1()
        {
            return View();
        }
        public IActionResult B1W_H()
        {
            return View();
        }
        public IActionResult B1FG_B1()
        {
            return View();
        }
        public IActionResult B2QAT()
        {
            return View();
        }
        public IActionResult B2SP_1()
        {
            return View();
        }
        public IActionResult B2SP_2()
        {
            return View();
        }
        public IActionResult B2SP_3()
        {
            return View();
        }
        public IActionResult B2SP_4()
        {
            return View();
        }
        public IActionResult B2ABC_WH()
        {
            return View();
        }
        public IActionResult B2REALIBILITY()
        {
            return View();
        }
        public IActionResult B2FG_B2()
        {
            return View();
        }

        //public JsonResult GetTempData()
        //{
        //    var data = _qr._query(@"Exec SP_Get_Temp_and_Humidity 'F2'");
        //    return data;
        //}
        //public JsonResult GetPressureData()
        //{
        //    var data = _qr._query(@"Exec SP_Get_Temp_and_Humidity 'F3'");
        //    return data;
        //}
        //public JsonResult GetRHData()
        //{
        //    var data = _qr._query(@"Exec SP_Get_Temp_and_Humidity 'F4'");
        //    return data;
        //}
        public JsonResult GetTempTable()
        {

            var data = _qr._query(@"Exec SP_GetTable_Temp_and_Humidity 'TBL_FacilityReport_ENVIRMENT'");
            return data;
        }
        //public JsonResult GetTempTable([FromBody] AreaModel area)
        //{

        //    var data = _qr._query(@"Exec SP_GetTable_Temp_and_Humidity " + "'" + area.area + "','TBL_FacilityReport_ENVIRMENT'");
        //    return data;
        //}
        public JsonResult PostTempData([FromBody] AreaModel temp)
        {
            var data = _qr._query(@"Exec SP_Get_Temp_and_Humidity " + "'" + temp.Temp + "','TBL_FacilityReport_ENVIRMENT'");
            return data;
        }
        public JsonResult PostPressureData([FromBody] AreaModel Pressure)
        {
            var data = _qr._query(@"Exec SP_Get_Temp_and_Humidity " + "'" + Pressure.Pressure + "','TBL_FacilityReport_ENVIRMENT'");
            return data;
        }
        public JsonResult PostRHData([FromBody] AreaModel RH)
        {
            var data = _qr._query(@"Exec SP_Get_Temp_and_Humidity " + "'" + RH.RH + "','TBL_FacilityReport_ENVIRMENT'");
            return data;
        }

        //Building 2
        public JsonResult PostTempDataB2([FromBody] AreaModel temp)
        {
            var data = _qr._query(@"Exec SP_Get_Temp_and_Humidity " + "'" + temp.Temp + "','TBL_FacilityReport_B2_ENVIRONMENT'");
            return data;
        }
        public JsonResult PostPressureDataB2([FromBody] AreaModel Pressure)
        {
            var data = _qr._query(@"Exec SP_Get_Temp_and_Humidity " + "'" + Pressure.Pressure + "','TBL_FacilityReport_B2_ENVIRONMENT'");
            return data;
        }
        public JsonResult PostRHDataB2([FromBody] AreaModel RH)
        {
            var data = _qr._query(@"Exec SP_Get_Temp_and_Humidity " + "'" + RH.RH + "','TBL_FacilityReport_B2_ENVIRONMENT'");
            return data;
        }

    }
}
