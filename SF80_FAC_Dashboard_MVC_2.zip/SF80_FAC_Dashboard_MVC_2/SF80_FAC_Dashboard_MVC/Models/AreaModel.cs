﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SF80_FAC_Dashboard_MVC.Models
{
    public class AreaModel
    {
        public string area { get; set; }
        public string areaselect { get; set; }
        public string Temp { get; set; }
        public string Pressure { get; set; }
        public string RH { get; set; }



    }
}
