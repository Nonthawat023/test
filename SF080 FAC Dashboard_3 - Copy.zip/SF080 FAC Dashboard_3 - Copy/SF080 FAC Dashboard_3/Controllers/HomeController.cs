﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SF080_FAC_Dashboard_3.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace SF080_FAC_Dashboard_3.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly SF080_Dashboard_3.Controllers.QueryController _qr;
        private dynamic click;
        public HomeController(ILogger<HomeController> logger, SF080_Dashboard_3.Controllers.QueryController _qr)
        {
            _logger = logger;
            this._qr = _qr;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult Sensor()
        {
            return View();
        }
        public IActionResult Electric()
        {
            return View();
        }
        public IActionResult Page1()
        {
            return View();
        }
        public IActionResult Page2()
        {
            return View();
        }
        public IActionResult MP()
        {
            return View();
        }
        public IActionResult Dashboard()
        {
            return View();
        }
        public JsonResult GetMCTotalStatus()
        {
            var data = _qr._query(@"Exec sp_DMachine_TotalStatus 'Input','IS' ");
            return data;
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
